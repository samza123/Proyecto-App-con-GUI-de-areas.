/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Menú de la sección Álgebra Lineal. Permite navegar a Gauss-Jordan y Eliminación Gaussiana.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class Algebra extends JFrame{
    ProyectoIntApp padre;
    JButton volver = new JButton("Volver");
    JButton jordan = new JButton("Gauss-Jordan");
    JButton gaussiana = new JButton("Eliminación Gaussiana");
    JButton salir = new JButton("Salir");

    /**
     * Constructor. Inicializa y muestra el menú de Álgebra Lineal.
     *
     * @param padre ventana principal de la aplicación
     */
    public Algebra(ProyectoIntApp padre) {
        super("Algebra");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(30, 10, 50));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }
            
    /**
     * Construye y agrega los componentes visuales del menú.
     */
    public void crearGUI() {
        JLabel titulo = new JLabel("ÁLGEBRA LINEAL - SELECCIONA UN TEMA");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(142, 68, 173));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);
        
        ProyectoIntApp.estilizarBoton(jordan, new Color(142, 68, 173));
        jordan.setBounds((1024-300)/2, 200, 300, 45);
        jordan.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jordan.addActionListener((e) -> { setVisible(false); new GaussJordan(this); });
        add(jordan);
        
        ProyectoIntApp.estilizarBoton(gaussiana, new Color(108, 52, 131));
        gaussiana.setBounds((1024-300)/2, 300, 300, 45);
        gaussiana.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gaussiana.addActionListener((e) -> { setVisible(false); new Gaussiana(this); });
        add(gaussiana);

        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);
        
        ProyectoIntApp.estilizarBoton(salir, new Color(192, 57, 43));
        salir.setBounds(838, 560, 150, 30);
        salir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        salir.addActionListener((e) -> evento_salir());
        add(salir);
    }
    
    /**
     * Cierra esta ventana y vuelve al menú principal.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }
    
    /**
     * Solicita confirmación y cierra la aplicación si el usuario acepta.
     */
    public void evento_salir() {
        int respuesta = JOptionPane.showConfirmDialog(this, "¿Desea realmente salir de la aplicación?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if(respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
}
