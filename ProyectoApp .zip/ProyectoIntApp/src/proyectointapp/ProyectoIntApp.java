/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana principal de la aplicación educativa interactiva.
 * Muestra el menú de navegación hacia cada área del conocimiento.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class ProyectoIntApp extends JFrame{
    
    static final Color C_FONDO      = new Color(15, 25, 50);
    static final Color C_TITULO_BG  = new Color(30, 50, 100);
    static final Color C_TITULO_FG  = new Color(255, 220, 50);
    static final Color C_MATE       = new Color(41, 128, 185);
    static final Color C_FISICA     = new Color(39, 174, 96);
    static final Color C_ALGEBRA    = new Color(142, 68, 173);
    static final Color C_HUMAN      = new Color(211, 84, 0);
    static final Color C_TGS        = new Color(52, 152, 219);
    static final Color C_AYUDA      = new Color(22, 160, 133);
    static final Color C_ACERCA     = new Color(44, 62, 80);
    static final Color C_SALIR      = new Color(192, 57, 43);
    static final Color C_BTN_TEXT   = Color.WHITE;

    JButton mate = new JButton("Matemáticas");
    JButton fisica = new JButton("Física");
    JButton algebra = new JButton("Álgebra Lineal");
    JButton humanidades = new JButton("Humanidades");
    JButton tgs = new JButton("Teoría General de Sistemas");
    JButton ayuda = new JButton("Ayuda");
    JButton acerca_de = new JButton("Acerca de");
    JButton salir = new JButton("Salir");

    /**
     * Constructor. Configura y muestra la ventana principal.
     */
    public ProyectoIntApp() {
        super("< Menú Principal PI >");
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(C_FONDO);
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    /**
     * Construye y agrega todos los componentes visuales del menú principal.
     */
    public void crearGUI() {
        JLabel titulo = new JLabel("MENÚ PRINCIPAL - SELECCIONA UNA OPCIÓN");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(C_TITULO_BG);
        titulo.setForeground(C_TITULO_FG);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);

        estilizarBoton(mate, C_MATE);
        mate.setBounds((1024-300)/2, 120, 300, 45);
        mate.setCursor(new Cursor(Cursor.HAND_CURSOR));
        mate.addActionListener((e) -> { setVisible(false); new Matematicas(this); });
        add(mate);
        
        estilizarBoton(fisica, C_FISICA);
        fisica.setBounds((1024-300)/2, 170, 300, 45);
        fisica.setCursor(new Cursor(Cursor.HAND_CURSOR));
        fisica.addActionListener((e) -> { setVisible(false); new Fisica(this); });
        add(fisica);
        
        estilizarBoton(algebra, C_ALGEBRA);
        algebra.setBounds((1024-300)/2, 270, 300, 45);
        algebra.setCursor(new Cursor(Cursor.HAND_CURSOR));
        algebra.addActionListener((e) -> { setVisible(false); new Algebra(this); });
        add(algebra);
        
        estilizarBoton(humanidades, C_HUMAN);
        humanidades.setBounds((1024-300)/2, 220, 300, 45);
        humanidades.setCursor(new Cursor(Cursor.HAND_CURSOR));
        humanidades.addActionListener((e) -> { setVisible(false); new Humanidades(this); });
        add(humanidades);
        
        estilizarBoton(tgs, C_TGS);
        tgs.setBounds((1024-300)/2, 320, 300, 45);
        tgs.setCursor(new Cursor(Cursor.HAND_CURSOR));
        tgs.addActionListener((e) -> { setVisible(false); new TeoriaGeneralSistemas(this); });
        add(tgs);
        
        estilizarBoton(ayuda, C_AYUDA);
        ayuda.setBounds((1024-300)/2, 400, 300, 45);
        ayuda.setCursor(new Cursor(Cursor.HAND_CURSOR));
        ayuda.addActionListener((e) -> { setVisible(false); new Ayuda(this); });
        add(ayuda);
        
        estilizarBoton(acerca_de, C_ACERCA);
        acerca_de.setBounds((1024-300)/2, 450, 300, 45);
        acerca_de.setCursor(new Cursor(Cursor.HAND_CURSOR));
        acerca_de.addActionListener((e) -> { setVisible(false); new AcercaDe(this); });
        add(acerca_de);
        
        estilizarBoton(salir, C_SALIR);
        salir.setBounds((1024-300)/2, 500, 300, 45);
        salir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        salir.addActionListener((e) -> evento_salir());
        add(salir);
    }
    
    /**
     * Aplica estilo visual uniforme a un botón.
     *
     * @param btn   botón a estilizar
     * @param fondo color de fondo del botón
     */
    public static void estilizarBoton(JButton btn, Color fondo) {
        btn.setBackground(fondo);
        btn.setForeground(C_BTN_TEXT);
        btn.setFont(new Font("Arial", Font.BOLD, 16));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setOpaque(true);
    }
    
    /**
     * Solicita confirmación al usuario y cierra la aplicación si acepta.
     */
    public void evento_salir() {
        int respuesta = JOptionPane.showConfirmDialog(this, "¿Desea realmente salir de la aplicación?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if(respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
    
    /**
     * Punto de entrada de la aplicación.
     *
     * @param args argumentos de línea de comandos (no utilizados)
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(ProyectoIntApp::new);
    }
}
