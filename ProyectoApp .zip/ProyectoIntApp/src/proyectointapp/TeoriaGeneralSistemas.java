/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Collections;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.Timer;

/**
 * Minijuego de preguntas y respuestas sobre Teoría General de Sistemas.
 * El jugador responde 20 preguntas con temporizador de 40 segundos y 3 vidas.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class TeoriaGeneralSistemas extends JFrame {

    ProyectoIntApp menu;

    JLabel titulo;
    JLabel pregunta;
    JLabel puntosLabel;
    JLabel vidasLabel;
    JLabel tiempoLabel;

    JButton op1, op2, op3, op4;

    JProgressBar progreso;

    Timer timer;

    int tiempo = 40;
    int puntos = 0;
    int vidas = 3;
    int preguntaActual = 0;

    ArrayList<String[]> preguntas = new ArrayList<>();

    /**
     * Constructor. Inicializa el juego, mezcla las preguntas y muestra la ventana.
     *
     * @param menu ventana principal de la aplicación
     */
    public TeoriaGeneralSistemas(ProyectoIntApp menu) {

        this.menu = menu;

        setTitle("Teoría General de Sistemas");
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setLayout(null);

        getContentPane().setBackground(new Color(8, 8, 25));

        iniciarPreguntas();

        Collections.shuffle(preguntas);

        titulo = new JLabel("MINIJUEGO TGS");
        titulo.setBounds(320, 20, 500, 50);
        titulo.setForeground(new Color(0, 255, 255));
        titulo.setFont(new Font("Arial", Font.BOLD, 34));
        add(titulo);

        puntosLabel = new JLabel("Puntos: 0");
        puntosLabel.setBounds(40, 90, 200, 40);
        puntosLabel.setForeground(Color.GREEN);
        puntosLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(puntosLabel);

        vidasLabel = new JLabel("VIDAS: 3");
        vidasLabel.setBounds(430, 90, 200, 40);
        vidasLabel.setForeground(Color.RED);
        vidasLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(vidasLabel);

        tiempoLabel = new JLabel("Tiempo: 40");
        tiempoLabel.setBounds(780, 90, 180, 40);
        tiempoLabel.setForeground(Color.ORANGE);
        tiempoLabel.setFont(new Font("Arial", Font.BOLD, 24));
        add(tiempoLabel);

        progreso = new JProgressBar();
        progreso.setBounds(220, 145, 580, 25);
        progreso.setMaximum(20);
        progreso.setValue(0);
        progreso.setStringPainted(true);
        add(progreso);

        pregunta = new JLabel("");
        pregunta.setBounds(70, 210, 900, 50);
        pregunta.setForeground(Color.WHITE);
        pregunta.setFont(new Font("Arial", Font.BOLD, 22));
        add(pregunta);

        op1 = crearBoton();
        op1.setBounds(250, 300, 500, 45);

        op2 = crearBoton();
        op2.setBounds(250, 360, 500, 45);

        op3 = crearBoton();
        op3.setBounds(250, 420, 500, 45);

        op4 = crearBoton();
        op4.setBounds(250, 480, 500, 45);

        add(op1);
        add(op2);
        add(op3);
        add(op4);

        JButton volver = new JButton("Volver");
        volver.setBounds(20, 550, 150, 40);
        volver.setBackground(new Color(192, 57, 43));
        volver.setForeground(Color.WHITE);
        volver.setFont(new Font("Arial", Font.BOLD, 18));

        volver.addActionListener((e) -> {
            dispose();
            menu.setVisible(true);
        });

        add(volver);

        iniciarTimer();

        cargarPregunta();

        setVisible(true);
    }

    /**
     * Crea un botón de opción con el estilo visual del minijuego.
     *
     * @return botón configurado con listener de respuesta
     */
    private JButton crearBoton() {

        JButton boton = new JButton();

        boton.setBackground(new Color(52, 152, 219));
        boton.setForeground(Color.WHITE);
        boton.setFont(new Font("Arial", Font.BOLD, 18));

        boton.addActionListener((e) -> {

            JButton seleccionado = (JButton) e.getSource();

            verificarRespuesta(seleccionado.getText());

        });

        return boton;
    }

    /**
     * Inicia el temporizador de cuenta regresiva por pregunta (40 segundos).
     * Resta una vida si el tiempo se agota.
     */
    private void iniciarTimer() {

        timer = new Timer(1000, e -> {

            tiempo--;

            tiempoLabel.setText("Tiempo: " + tiempo);

            if (tiempo <= 0) {

                vidas--;

                actualizarVidas();

                JOptionPane.showMessageDialog(this,
                        "⏰ Tiempo agotado");

                siguientePregunta();
            }

        });

        timer.start();
    }

    /**
     * Reinicia el contador de tiempo a 40 segundos para la siguiente pregunta.
     */
    private void reiniciarTiempo() {

        tiempo = 40;

        tiempoLabel.setText("Tiempo: 40");
    }

    /**
     * Muestra la pregunta actual con sus cuatro opciones. Finaliza el juego si no hay más.
     */
    private void cargarPregunta() {

        if (preguntaActual >= preguntas.size()) {

            timer.stop();

            JOptionPane.showMessageDialog(this,
                    "🏆 Juego terminado\nPuntaje final: " + puntos);

            dispose();

            menu.setVisible(true);

            return;
        }

        progreso.setValue(preguntaActual);

        String[] p = preguntas.get(preguntaActual);

        pregunta.setText(p[0]);

        op1.setText(p[1]);
        op2.setText(p[2]);
        op3.setText(p[3]);
        op4.setText(p[4]);

        reiniciarTiempo();
    }

    /**
     * Compara la respuesta seleccionada con la correcta y actualiza puntos o vidas.
     *
     * @param respuesta texto de la opción seleccionada por el usuario
     */
    private void verificarRespuesta(String respuesta) {

        String correcta = preguntas.get(preguntaActual)[5];

        if (respuesta.equals(correcta)) {

            puntos += 10;

            JOptionPane.showMessageDialog(this,
                    "✅ Correcto");

        } else {

            vidas--;

            actualizarVidas();

            JOptionPane.showMessageDialog(this,
                    "❌ Incorrecto");

        }

        puntosLabel.setText("Puntos: " + puntos);

        siguientePregunta();
    }

    /**
     * Avanza a la siguiente pregunta o termina el juego si no quedan vidas.
     */
    private void siguientePregunta() {

        if (vidas <= 0) {

            timer.stop();

            JOptionPane.showMessageDialog(this,
                    "💀 GAME OVER");

            dispose();

            menu.setVisible(true);

            return;
        }

        preguntaActual++;

        cargarPregunta();
    }

    /**
     * Actualiza la etiqueta de vidas restantes en pantalla.
     */
    private void actualizarVidas() {

        vidasLabel.setText("VIDAS: " + vidas);
    }

    /**
     * Carga el banco de preguntas sobre Pensamiento Sistémico, Elementos de Sistemas y Organicidad.
     */
    private void iniciarPreguntas() {

        // PENSAMIENTO SISTÉMICO

        preguntas.add(new String[]{
            "¿Qué analiza el pensamiento sistémico?",
            "Elementos aislados",
            "Relaciones entre elementos",
            "Solo procesos",
            "Solo entradas",
            "Relaciones entre elementos"
        });

        preguntas.add(new String[]{
            "¿Qué busca comprender el pensamiento sistémico?",
            "Solo resultados",
            "Partes separadas",
            "El sistema completo",
            "Solo errores",
            "El sistema completo"
        });

        preguntas.add(new String[]{
            "¿Qué es fundamental en un sistema?",
            "Separación",
            "Desorden",
            "Interacción",
            "Aislamiento",
            "Interacción"
        });

        preguntas.add(new String[]{
            "¿Qué enfoque utiliza la TGS?",
            "Fragmentado",
            "Simple",
            "Individual",
            "Integral",
            "Integral"
        });

        preguntas.add(new String[]{
            "¿Qué permite identificar el pensamiento sistémico?",
            "Datos aislados",
            "Procesos únicos",
            "Patrones",
            "Errores humanos",
            "Patrones"
        });

        // ELEMENTOS DE SISTEMAS

        preguntas.add(new String[]{
            "¿Qué transforma entradas en salidas?",
            "Límite",
            "Proceso",
            "Entorno",
            "Subsistema",
            "Proceso"
        });

        preguntas.add(new String[]{
            "¿Qué recibe un sistema?",
            "Retroalimentación",
            "Entradas",
            "Control",
            "Procesos",
            "Entradas"
        });

        preguntas.add(new String[]{
            "¿Qué genera un sistema?",
            "Control",
            "Entropía",
            "Salidas",
            "Límites",
            "Salidas"
        });

        preguntas.add(new String[]{
            "¿Qué rodea al sistema?",
            "Entorno",
            "Proceso",
            "Entrada",
            "Control",
            "Entorno"
        });

        preguntas.add(new String[]{
            "¿Qué separa un sistema del entorno?",
            "Proceso",
            "Salida",
            "Límite",
            "Sinergia",
            "Límite"
        });

        preguntas.add(new String[]{
            "¿Qué corrige errores del sistema?",
            "Salida",
            "Retroalimentación",
            "Proceso",
            "Entrada",
            "Retroalimentación"
        });

        preguntas.add(new String[]{
            "¿Qué son partes internas del sistema?",
            "Variables",
            "Subsistemas",
            "Entornos",
            "Salidas",
            "Subsistemas"
        });

        preguntas.add(new String[]{
            "¿Qué mantiene estable un sistema?",
            "Desorden",
            "Fragmentación",
            "Caos",
            "Control",
            "Control"
        });

        preguntas.add(new String[]{
            "¿Qué intercambia energía con el entorno?",
            "Sistema cerrado",
            "Sistema abierto",
            "Sistema lineal",
            "Sistema aislado",
            "Sistema abierto"
        });

        preguntas.add(new String[]{
            "¿Qué representa el desorden en un sistema?",
            "Sinergia",
            "Retroalimentación",
            "Entropía",
            "Control",
            "Entropía"
        });

        // ORGANICIDAD

        preguntas.add(new String[]{
            "¿Qué principio indica trabajo conjunto?",
            "Separación",
            "Organicidad",
            "Desorden",
            "Aislamiento",
            "Organicidad"
        });

        preguntas.add(new String[]{
            "¿Qué ocurre si falla una parte del sistema?",
            "No ocurre nada",
            "Afecta al conjunto",
            "Se aísla",
            "Mejora el sistema",
            "Afecta al conjunto"
        });

        preguntas.add(new String[]{
            "¿Qué caracteriza a un sistema orgánico?",
            "Rigidez",
            "Separación",
            "Interdependencia",
            "Aislamiento",
            "Interdependencia"
        });

        preguntas.add(new String[]{
            "¿Qué principio relaciona cooperación entre partes?",
            "Fragmentación",
            "Límite",
            "Sinergia",
            "Entropía",
            "Sinergia"
        });

        preguntas.add(new String[]{
            "¿Qué busca mantener equilibrio?",
            "Entropía",
            "Homeostasis",
            "Caos",
            "Aislamiento",
            "Homeostasis"
        });

    }

}