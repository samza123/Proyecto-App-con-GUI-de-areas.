/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana educativa sobre el documental "El Mundo Según Monsanto".
 * Presenta una lectura informativa y un cuestionario de 5 preguntas con retroalimentación.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class MundoSegunMonsanto extends JFrame {

    Humanidades padre;
    JButton volver  = new JButton("Volver");
    JButton salir   = new JButton("Salir");
    JButton iniciar = new JButton("Iniciar Cuestionario ▶");

    // ── Cuestionario ──────────────────────────────────────────────────────
    private static final String[] PREGUNTAS = {
        "1. ¿Qué es 'El Mundo Según Monsanto'?",
        "2. ¿Cuál es el herbicida más conocido fabricado y promovido por Monsanto?",
        "3. ¿Qué práctica cuestionable se denuncia en el documental respecto a los agricultores?",
        "4. ¿Qué sucedió con Monsanto en 2018?",
        "5. ¿Cuál es una de las principales críticas al modelo de negocio de Monsanto/Bayer?"
    };

    private static final String[][] OPCIONES = {
        {"a) Un libro de cocina sobre alimentos orgánicos",
         "b) Un documental de 2008 que investiga las prácticas y el poder de la empresa Monsanto",
         "c) Un informe científico favorable a los transgénicos publicado por la OMS",
         "d) Una serie de televisión sobre agricultura sostenible"},
        {"a) DDT",
         "b) Atrazina",
         "c) Glifosato (comercializado como Roundup)",
         "d) Paraquat"},
        {"a) Monsanto regalaba semillas a los agricultores pobres",
         "b) Monsanto patentó semillas y persiguió legalmente a agricultores por resembrar sus propias cosechas",
         "c) Monsanto financiaba investigaciones independientes sobre seguridad alimentaria",
         "d) Monsanto promovía la diversidad de cultivos nativos en zonas rurales"},
        {"a) Fue declarada empresa del año por la ONU",
         "b) Cerró sus operaciones por falta de rentabilidad",
         "c) Fue adquirida por la empresa alemana Bayer AG",
         "d) Se fusionó con la FAO para proyectos de hambre cero"},
        {"a) Producir demasiados alimentos baratos para los consumidores",
         "b) La concentración del control de semillas en pocas corporaciones, amenazando la soberanía alimentaria",
         "c) Invertir demasiado en investigación pública universitaria",
         "d) Apoyar en exceso a los pequeños agricultores locales"}
    };

    private static final int[] RESPUESTAS = {1, 2, 1, 2, 1};

    private int preguntaActual = 0;
    private int puntaje = 0;

    private JLabel lblPregunta;
    private JRadioButton[] radios;
    private ButtonGroup grupo;
    private JButton btnSiguiente;
    private JPanel panelQuiz;
    private JPanel panelLectura;

    /**
     * Constructor. Inicializa y muestra la ventana del tema Monsanto.
     *
     * @param padre ventana del menú de Humanidades
     */
    public MundoSegunMonsanto(Humanidades padre) {
        super("Humanidades - El Mundo Según Monsanto");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(20, 15, 5));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {

        // ── Título ──────────────────────────────────────────────────────
        JLabel titulo = new JLabel("EL MUNDO SEGÚN MONSANTO");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(160, 64, 0));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 33));
        add(titulo);

        // ── Panel de lectura ─────────────────────────────────────────────
        panelLectura = new JPanel();
        panelLectura.setLayout(null);
        panelLectura.setBackground(new Color(35, 18, 5));
        panelLectura.setBounds(30, 75, 960, 390);
        add(panelLectura);

        JLabel lblTituloLectura = new JLabel("📖  Lectura: El Mundo Según Monsanto");
        lblTituloLectura.setBounds(15, 8, 900, 30);
        lblTituloLectura.setForeground(new Color(255, 165, 50));
        lblTituloLectura.setFont(new Font("Arial", Font.BOLD, 18));
        panelLectura.add(lblTituloLectura);

        String texto = "<html><body style='width:880px; color:#F5DEB3; font-size:13px;'>"
            + "<b>'El Mundo Según Monsanto'</b> (2008) es un documental de la directora francesa Marie-Monique Robin que "
            + "investiga la historia, las prácticas y el poder de la empresa multinacional <b>Monsanto</b>, una de las mayores "
            + "productoras de semillas transgénicas y herbicidas del mundo.<br><br>"
            + "El documental denuncia que Monsanto, creadora del herbicida <b>Roundup</b> (cuyo principio activo es el "
            + "<b>glifosato</b>), ha minimizado deliberadamente los riesgos de sus productos para la salud humana y el "
            + "medioambiente. También expone cómo la empresa patentó sus semillas transgénicas y persiguió legalmente a "
            + "agricultores que resembraban sus propias cosechas o cuyos cultivos fueron contaminados por polinización cruzada.<br><br>"
            + "<b>Temas clave del documental:</b> El uso del agente naranja durante la guerra de Vietnam (producido por Monsanto), "
            + "la relación entre la empresa y organismos reguladores, la 'puerta giratoria' entre ejecutivos corporativos y "
            + "cargos gubernamentales, y el impacto social en comunidades agrícolas de países como México, India y Argentina.<br><br>"
            + "En 2018, Monsanto fue adquirida por la empresa alemana <b>Bayer AG</b>, que heredó miles de demandas judiciales "
            + "relacionadas con el glifosato. El caso sigue siendo un referente global en debates sobre <b>soberanía alimentaria</b>, "
            + "poder corporativo y regulación de biotecnología agrícola."
            + "</body></html>";

        JLabel lblTexto = new JLabel(texto);
        lblTexto.setBounds(15, 42, 930, 340);
        lblTexto.setVerticalAlignment(JLabel.TOP);
        panelLectura.add(lblTexto);

        // ── Botón iniciar cuestionario ───────────────────────────────────
        ProyectoIntApp.estilizarBoton(iniciar, new Color(160, 64, 0));
        iniciar.setBounds((1024 - 260) / 2, 480, 260, 45);
        iniciar.setFont(new Font("Arial", Font.BOLD, 16));
        iniciar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iniciar.addActionListener((e) -> mostrarCuestionario());
        add(iniciar);

        // ── Panel del cuestionario (oculto) ──────────────────────────────
        panelQuiz = new JPanel();
        panelQuiz.setLayout(null);
        panelQuiz.setBackground(new Color(35, 18, 5));
        panelQuiz.setBounds(30, 75, 960, 450);
        panelQuiz.setVisible(false);
        add(panelQuiz);

        lblPregunta = new JLabel();
        lblPregunta.setBounds(15, 15, 930, 50);
        lblPregunta.setForeground(new Color(255, 200, 80));
        lblPregunta.setFont(new Font("Arial", Font.BOLD, 16));
        panelQuiz.add(lblPregunta);

        radios = new JRadioButton[4];
        grupo = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            radios[i] = new JRadioButton();
            radios[i].setBounds(30, 80 + i * 60, 900, 40);
            radios[i].setBackground(new Color(35, 18, 5));
            radios[i].setForeground(new Color(245, 222, 179));
            radios[i].setFont(new Font("Arial", Font.PLAIN, 15));
            radios[i].setFocusPainted(false);
            grupo.add(radios[i]);
            panelQuiz.add(radios[i]);
        }

        btnSiguiente = new JButton("Siguiente ▶");
        ProyectoIntApp.estilizarBoton(btnSiguiente, new Color(160, 64, 0));
        btnSiguiente.setBounds((960 - 200) / 2, 380, 200, 40);
        btnSiguiente.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSiguiente.addActionListener((e) -> evaluarRespuesta());
        panelQuiz.add(btnSiguiente);

        // ── Botones de navegación ────────────────────────────────────────
        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);

        ProyectoIntApp.estilizarBoton(salir, new Color(192, 57, 43));
        salir.setBounds(838, 560, 150, 30);
        salir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        salir.addActionListener((e) -> evento_salir());
        add(salir);
    }

    /**
     * Oculta la lectura y muestra el panel del cuestionario desde la primera pregunta.
     */
    private void mostrarCuestionario() {
        preguntaActual = 0;
        puntaje = 0;
        panelLectura.setVisible(false);
        iniciar.setVisible(false);
        panelQuiz.setVisible(true);
        cargarPregunta();
    }

    /**
     * Carga el texto y las opciones de la pregunta actual en los componentes del panel.
     */
    private void cargarPregunta() {
        grupo.clearSelection();
        lblPregunta.setText("<html>" + PREGUNTAS[preguntaActual] + "</html>");
        for (int i = 0; i < 4; i++) {
            radios[i].setText(OPCIONES[preguntaActual][i]);
        }
        boolean ultima = (preguntaActual == PREGUNTAS.length - 1);
        btnSiguiente.setText(ultima ? "Ver Resultado ✔" : "Siguiente ▶");
    }

    /**
     * Verifica la opción seleccionada, muestra retroalimentación y avanza a la siguiente pregunta.
     */
    private void evaluarRespuesta() {
        int seleccionada = -1;
        for (int i = 0; i < 4; i++) {
            if (radios[i].isSelected()) { seleccionada = i; break; }
        }
        if (seleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una opción antes de continuar.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (seleccionada == RESPUESTAS[preguntaActual]) {
            puntaje++;
            JOptionPane.showMessageDialog(this, "✅  ¡Correcto!", "Respuesta", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String correcta = OPCIONES[preguntaActual][RESPUESTAS[preguntaActual]];
            JOptionPane.showMessageDialog(this, "❌  Incorrecto.\nRespuesta correcta: " + correcta, "Respuesta", JOptionPane.ERROR_MESSAGE);
        }
        preguntaActual++;
        if (preguntaActual < PREGUNTAS.length) {
            cargarPregunta();
        } else {
            panelQuiz.setVisible(false);
            JOptionPane.showMessageDialog(this,
                "🎓  Cuestionario finalizado\nPuntaje: " + puntaje + " / " + PREGUNTAS.length,
                "Resultado", JOptionPane.INFORMATION_MESSAGE);
            panelLectura.setVisible(true);
            iniciar.setText("Repetir Cuestionario 🔄");
            iniciar.setVisible(true);
        }
    }

    /**
     * Cierra esta ventana y vuelve al menú de Humanidades.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }

    /**
     * Solicita confirmación y cierra la aplicación si el usuario acepta.
     */
    public void evento_salir() {
        int r = JOptionPane.showConfirmDialog(this, "¿Desea realmente salir de la aplicación?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) System.exit(0);
    }
}
