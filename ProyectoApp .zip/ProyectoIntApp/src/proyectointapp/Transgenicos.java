/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana educativa sobre organismos transgénicos (OGM).
 * Presenta una lectura y un cuestionario de 5 preguntas con retroalimentación inmediata.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class Transgenicos extends JFrame {

    Humanidades padre;
    JButton volver  = new JButton("Volver");
    JButton salir   = new JButton("Salir");
    JButton iniciar = new JButton("Iniciar Cuestionario ▶");

    // ── Cuestionario ──────────────────────────────────────────────────────
    private static final String[] PREGUNTAS = {
        "1. ¿Qué son los organismos genéticamente modificados (OGM)?",
        "2. ¿Cuál es uno de los argumentos principales a FAVOR de los transgénicos?",
        "3. ¿Cuál es uno de los argumentos en CONTRA de los transgénicos?",
        "4. ¿Qué técnica se usa para insertar genes de otra especie en una planta?",
        "5. ¿Qué organismo regula la aprobación de cultivos transgénicos en muchos países?"
    };

    private static final String[][] OPCIONES = {
        {"a) Organismos criados en condiciones controladas de laboratorio",
         "b) Organismos cuyo material genético ha sido alterado con genes de otra especie",
         "c) Organismos que se reproducen más rápido de forma natural",
         "d) Organismos que crecen sin uso de pesticidas"},
        {"a) Reducen la biodiversidad de los ecosistemas",
         "b) Son más resistentes a plagas, reduciendo el uso de pesticidas",
         "c) Contienen más químicos tóxicos que los cultivos convencionales",
         "d) Solo benefician a grandes corporaciones sin ningún uso agrícola"},
        {"a) Mayor rendimiento garantizado en todos los climas",
         "b) Menor costo de producción siempre",
         "c) Posible contaminación de cultivos orgánicos cercanos por polinización cruzada",
         "d) Mayor sabor y valor nutricional comprobado"},
        {"a) Clonación celular",
         "b) Fermentación dirigida",
         "c) Ingeniería genética mediante vectores o edición como CRISPR",
         "d) Hibridación tradicional entre variedades"},
        {"a) La OMS y la FAO en conjunto con cada gobierno nacional",
         "b) Solo las empresas biotecnológicas privadas",
         "c) Las universidades agrícolas de cada país",
         "d) Ningún organismo los regula actualmente"}
    };

    private static final int[] RESPUESTAS = {1, 1, 2, 2, 0}; // índice (0-based) de la correcta

    private int preguntaActual = 0;
    private int puntaje = 0;

    // Componentes del cuestionario (ocultos al inicio)
    private JLabel lblPregunta;
    private JRadioButton[] radios;
    private ButtonGroup grupo;
    private JButton btnSiguiente;
    private JPanel panelQuiz;
    private JPanel panelLectura;

    /**
     * Constructor. Inicializa y muestra la ventana de Transgénicos.
     *
     * @param padre ventana del menú de Humanidades
     */
    public Transgenicos(Humanidades padre) {
        super("Humanidades - Los Transgénicos");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(40, 20, 10));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {

        // ── Título ──────────────────────────────────────────────────────
        JLabel titulo = new JLabel("LOS TRANSGÉNICOS");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(211, 84, 0));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);

        // ── Panel de lectura ─────────────────────────────────────────────
        panelLectura = new JPanel();
        panelLectura.setLayout(null);
        panelLectura.setBackground(new Color(55, 28, 12));
        panelLectura.setBounds(30, 75, 960, 390);
        add(panelLectura);

        JLabel lblTituloLectura = new JLabel("📖  Lectura: ¿Qué son los transgénicos?");
        lblTituloLectura.setBounds(15, 8, 900, 30);
        lblTituloLectura.setForeground(new Color(255, 180, 80));
        lblTituloLectura.setFont(new Font("Arial", Font.BOLD, 18));
        panelLectura.add(lblTituloLectura);

        String texto = "<html><body style='width:880px; color:#F5DEB3; font-size:13px;'>"
            + "Los <b>organismos genéticamente modificados (OGM)</b>, también llamados <b>transgénicos</b>, son seres vivos cuyo "
            + "material genético ha sido alterado artificialmente mediante técnicas de ingeniería genética. Esto permite insertar, "
            + "eliminar o modificar genes de una especie en el genoma de otra, algo que no ocurre de forma natural ni mediante "
            + "hibridación convencional.<br><br>"
            + "Los principales cultivos transgénicos a nivel mundial son la <b>soja, el maíz, el algodón y la canola</b>. Fueron "
            + "desarrollados principalmente para ser resistentes a herbicidas (como el glifosato) o a insectos plagas.<br><br>"
            + "<b>Argumentos a favor:</b> Mayor rendimiento, menor uso de pesticidas en algunos casos, cultivos resistentes a "
            + "sequías, y reducción de pérdidas por plagas.<br><br>"
            + "<b>Argumentos en contra:</b> Posible contaminación genética de cultivos orgánicos, dependencia de patentes de "
            + "empresas como Monsanto (ahora Bayer), pérdida de biodiversidad, y debates sobre impacto en la salud humana a largo plazo.<br><br>"
            + "La comunidad científica sigue debatiendo sus efectos, y su cultivo está regulado (o prohibido) de manera muy "
            + "distinta en cada país."
            + "</body></html>";

        JLabel lblTexto = new JLabel(texto);
        lblTexto.setBounds(15, 42, 930, 340);
        lblTexto.setVerticalAlignment(JLabel.TOP);
        panelLectura.add(lblTexto);

        // ── Botón iniciar cuestionario ───────────────────────────────────
        ProyectoIntApp.estilizarBoton(iniciar, new Color(211, 84, 0));
        iniciar.setBounds((1024 - 260) / 2, 480, 260, 45);
        iniciar.setFont(new Font("Arial", Font.BOLD, 16));
        iniciar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        iniciar.addActionListener((e) -> mostrarCuestionario());
        add(iniciar);

        // ── Panel del cuestionario (oculto) ──────────────────────────────
        panelQuiz = new JPanel();
        panelQuiz.setLayout(null);
        panelQuiz.setBackground(new Color(55, 28, 12));
        panelQuiz.setBounds(30, 75, 960, 450);
        panelQuiz.setVisible(false);
        add(panelQuiz);

        lblPregunta = new JLabel();
        lblPregunta.setBounds(15, 15, 930, 50);
        lblPregunta.setForeground(new Color(255, 220, 100));
        lblPregunta.setFont(new Font("Arial", Font.BOLD, 16));
        panelQuiz.add(lblPregunta);

        radios = new JRadioButton[4];
        grupo = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            radios[i] = new JRadioButton();
            radios[i].setBounds(30, 80 + i * 60, 900, 40);
            radios[i].setBackground(new Color(55, 28, 12));
            radios[i].setForeground(new Color(245, 222, 179));
            radios[i].setFont(new Font("Arial", Font.PLAIN, 15));
            radios[i].setFocusPainted(false);
            grupo.add(radios[i]);
            panelQuiz.add(radios[i]);
        }

        btnSiguiente = new JButton("Siguiente ▶");
        ProyectoIntApp.estilizarBoton(btnSiguiente, new Color(211, 84, 0));
        btnSiguiente.setBounds((960 - 200) / 2, 380, 200, 40);
        btnSiguiente.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnSiguiente.addActionListener((e) -> evaluarRespuesta());
        panelQuiz.add(btnSiguiente);

        // ── Botones de navegación ────────────────────────────────────────
        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);

        ProyectoIntApp.estilizarBoton(salir, new Color(192, 57, 43));
        salir.setBounds(838, 560, 150, 30);
        salir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        salir.addActionListener((e) -> evento_salir());
        add(salir);
    }

    /**
     * Oculta la lectura y muestra el panel del cuestionario desde la primera pregunta.
     */
    private void mostrarCuestionario() {
        preguntaActual = 0;
        puntaje = 0;
        panelLectura.setVisible(false);
        iniciar.setVisible(false);
        panelQuiz.setVisible(true);
        cargarPregunta();
    }

    /**
     * Carga el texto y las opciones de la pregunta actual en los componentes del panel.
     */
    private void cargarPregunta() {
        grupo.clearSelection();
        lblPregunta.setText("<html>" + PREGUNTAS[preguntaActual] + "</html>");
        for (int i = 0; i < 4; i++) {
            radios[i].setText(OPCIONES[preguntaActual][i]);
        }
        boolean ultima = (preguntaActual == PREGUNTAS.length - 1);
        btnSiguiente.setText(ultima ? "Ver Resultado ✔" : "Siguiente ▶");
    }

    /**
     * Verifica la opción seleccionada, muestra retroalimentación y avanza a la siguiente pregunta.
     */
    private void evaluarRespuesta() {
        int seleccionada = -1;
        for (int i = 0; i < 4; i++) {
            if (radios[i].isSelected()) { seleccionada = i; break; }
        }
        if (seleccionada == -1) {
            JOptionPane.showMessageDialog(this, "Selecciona una opción antes de continuar.", "Atención", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (seleccionada == RESPUESTAS[preguntaActual]) {
            puntaje++;
            JOptionPane.showMessageDialog(this, "✅  ¡Correcto!", "Respuesta", JOptionPane.INFORMATION_MESSAGE);
        } else {
            String correcta = OPCIONES[preguntaActual][RESPUESTAS[preguntaActual]];
            JOptionPane.showMessageDialog(this, "❌  Incorrecto.\nRespuesta correcta: " + correcta, "Respuesta", JOptionPane.ERROR_MESSAGE);
        }
        preguntaActual++;
        if (preguntaActual < PREGUNTAS.length) {
            cargarPregunta();
        } else {
            panelQuiz.setVisible(false);
            JOptionPane.showMessageDialog(this,
                "🎓  Cuestionario finalizado\nPuntaje: " + puntaje + " / " + PREGUNTAS.length,
                "Resultado", JOptionPane.INFORMATION_MESSAGE);
            panelLectura.setVisible(true);
            iniciar.setText("Repetir Cuestionario 🔄");
            iniciar.setVisible(true);
        }
    }

    /**
     * Cierra esta ventana y vuelve al menú de Humanidades.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }

    /**
     * Solicita confirmación y cierra la aplicación si el usuario acepta.
     */
    public void evento_salir() {
        int r = JOptionPane.showConfirmDialog(this, "¿Desea realmente salir de la aplicación?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) System.exit(0);
    }
}
