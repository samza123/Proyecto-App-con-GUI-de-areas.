/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana para evaluar funciones matemáticas f(x) en un valor dado de x.
 * Soporta operadores básicos y funciones trigonométricas/trascendentes.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class Funciones extends JFrame{
    Matematicas padre;
    JButton volver = new JButton("Volver");
    JButton limpiar = new JButton("Limpiar");
    JButton calcular = new JButton("Calcular");
    JTextField funcion = new JTextField();
    JTextField valorX = new JTextField();
    JTextField res = new JTextField();

    /**
     * Constructor. Inicializa y muestra la ventana de Funciones.
     *
     * @param padre ventana del menú de Matemáticas
     */
    public Funciones(Matematicas padre) {
        super("Funciones");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(10, 30, 60));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }
    
    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {
        JLabel titulo = new JLabel("MATEMÁTICAS - FUNCIONES");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(41, 128, 185));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);
        
        JLabel datos = new JLabel("<html>f(x) = </html>");
        datos.setBounds(40, 100, 400, 30);
        datos.setFont(new Font("Arial", Font.ITALIC, 20));
        datos.setForeground(Color.WHITE);
        add(datos);
        
        JLabel ej_1 = new JLabel("<html>Ej: x^2 + 3*x + 2 | sin(x) | sqrt(x) | log(x)</html>");
        ej_1.setBounds(415, 100, 560, 30);
        ej_1.setFont(new Font("Arial", Font.ITALIC, 16));
        ej_1.setForeground(new Color(180, 210, 255));
        add(ej_1);
        
        funcion.setBounds(100, 100, 300, 30);
        add(funcion);
        
        JLabel x = new JLabel("<html>x = </html>");
        x.setBounds(60, 140, 400, 30);
        x.setFont(new Font("Arial", Font.ITALIC, 20));
        x.setForeground(Color.WHITE);
        add(x);
        
        JLabel x2 = new JLabel("<html>Ej: 2 </html>");
        x2.setBounds(238, 140, 400, 30);
        x2.setFont(new Font("Arial", Font.ITALIC, 20));
        x2.setForeground(new Color(180, 210, 255));
        add(x2);
        
        valorX.setBounds(100, 140, 120, 30);
        add(valorX);
        
        JLabel resu = new JLabel("<html>Resultado:</html>");
        resu.setBounds(100, 230, 400, 30);
        resu.setFont(new Font("Arial", Font.ITALIC, 25));
        resu.setForeground(new Color(255, 220, 80));
        add(resu);
        
        res.setBounds(100, 270, 800, 120);
        res.setEditable(false);
        res.setFont(new Font("Monospaced", Font.PLAIN, 16));
        add(res);
        
        JLabel nota = new JLabel("<html><b>Operadores:</b> + - * / ^ | Funciones: sin, cos, tan, sqrt, log, exp, abs</html>");
        nota.setBounds(100, 405, 800, 25);
        nota.setFont(new Font("Arial", Font.PLAIN, 13));
        nota.setForeground(new Color(150, 200, 255));
        add(nota);
        
        ProyectoIntApp.estilizarBoton(calcular, new Color(41, 128, 185));
        calcular.setBounds(100, 180, 120, 30);
        calcular.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calcular.addActionListener((e) -> evento_calcular());
        add(calcular);
        
        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);

        ProyectoIntApp.estilizarBoton(limpiar, new Color(22, 160, 133));
        limpiar.setBounds(190, 560, 150, 30);
        limpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        limpiar.addActionListener((e) -> evento_limpiar());
        add(limpiar);
    }
    
    /**
     * Cierra esta ventana y vuelve al menú de Matemáticas.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }
    
    /**
     * Borra los campos de entrada y el resultado.
     */
    public void evento_limpiar() {
        funcion.setText("");
        valorX.setText("");
        res.setText("");
        funcion.requestFocus();
    }
    
    /**
     * Lee la función y el valor de x, los evalúa y muestra el resultado.
     * Muestra advertencia si los campos están vacíos o tienen formato inválido.
     */
    public void evento_calcular() {
        String expr = funcion.getText().trim();
        String xStr = valorX.getText().trim();
        
        if (expr.isEmpty() || xStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa la función y el valor de x.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            double xVal = Double.parseDouble(xStr);
            double resultado = evaluarFuncion(expr, xVal);
            
            if (Double.isNaN(resultado)) {
                res.setText("Resultado: No definido (NaN)");
            } else if (Double.isInfinite(resultado)) {
                res.setText("Resultado: No definido (División por cero o infinito)");
            } else {
                String texto = String.format("f(%s) = %s\n\nf(%.4f) = %.6f", xStr, expr, xVal, resultado);
                res.setText(texto);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El valor de x debe ser un número válido.\nEj: 2, -1.5, 3.14", "Valor inválido", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al evaluar la función:\n" + e.getMessage() +
                "\n\nVerifica la sintaxis. Usa * para multiplicar.\nEj: 3*x^2 + 2*x - 1", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Sustituye x en la expresión y la evalúa numéricamente.
     *
     * @param expr expresión matemática como cadena (ej: "x^2 + 1")
     * @param x    valor numérico de la variable x
     * @return     resultado de evaluar f(x)
     */
    private double evaluarFuncion(String expr, double x) {
        expr = expr.toLowerCase().trim();
        expr = expr.replace("pi", String.valueOf(Math.PI));
        expr = expr.replace("e", String.valueOf(Math.E));
        expr = expr.replace("x", "(" + x + ")");
        return evaluarExpresion(expr);
    }
    
    /**
     * Inicia el análisis recursivo de la expresión.
     *
     * @param expr expresión preprocesada sin variable x
     * @return     valor numérico resultante
     */
    private double evaluarExpresion(String expr) {
        expr = expr.trim();
        return parseSuma(expr, new int[]{0});
    }
    
    /**
     * Analiza sumas y restas en la expresión.
     *
     * @param expr expresión completa
     * @param pos  posición actual del analizador (arreglo de un elemento)
     * @return     resultado parcial
     */
    private double parseSuma(String expr, int[] pos) {
        double resultado = parseMultiplica(expr, pos);
        while (pos[0] < expr.length()) {
            char c = expr.charAt(pos[0]);
            if (c == '+') { pos[0]++; resultado += parseMultiplica(expr, pos); }
            else if (c == '-') { pos[0]++; resultado -= parseMultiplica(expr, pos); }
            else break;
        }
        return resultado;
    }
    
    /**
     * Analiza multiplicaciones y divisiones en la expresión.
     *
     * @param expr expresión completa
     * @param pos  posición actual del analizador
     * @return     resultado parcial
     */
    private double parseMultiplica(String expr, int[] pos) {
        double resultado = parsePotencia(expr, pos);
        while (pos[0] < expr.length()) {
            char c = expr.charAt(pos[0]);
            if (c == '*') { pos[0]++; resultado *= parsePotencia(expr, pos); }
            else if (c == '/') { pos[0]++; resultado /= parsePotencia(expr, pos); }
            else break;
        }
        return resultado;
    }
    
    /**
     * Analiza potencias (operador ^) en la expresión.
     *
     * @param expr expresión completa
     * @param pos  posición actual del analizador
     * @return     resultado parcial
     */
    private double parsePotencia(String expr, int[] pos) {
        double base = parseUnario(expr, pos);
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '^') {
            pos[0]++;
            double exp = parseUnario(expr, pos);
            return Math.pow(base, exp);
        }
        return base;
    }
    
    /**
     * Maneja signos unarios (+ y -) antes de un valor primario.
     *
     * @param expr expresión completa
     * @param pos  posición actual del analizador
     * @return     resultado con signo aplicado
     */
    private double parseUnario(String expr, int[] pos) {
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '-') { pos[0]++; return -parsePrimario(expr, pos); }
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '+') { pos[0]++; }
        return parsePrimario(expr, pos);
    }
    
    /**
     * Analiza valores primarios: paréntesis, funciones matemáticas y números.
     *
     * @param expr expresión completa
     * @param pos  posición actual del analizador
     * @return     valor del token primario
     * @throws RuntimeException si la expresión es inválida en la posición actual
     */
    private double parsePrimario(String expr, int[] pos) {
        while (pos[0] < expr.length() && expr.charAt(pos[0]) == ' ') pos[0]++;
        
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '(') {
            pos[0]++;
            double val = parseSuma(expr, pos);
            if (pos[0] < expr.length() && expr.charAt(pos[0]) == ')') pos[0]++;
            return val;
        }
        
        String[] funciones = {"sin", "cos", "tan", "sqrt", "log10", "log", "exp", "abs"};
        for (String f : funciones) {
            if (expr.startsWith(f, pos[0])) {
                pos[0] += f.length();
                while (pos[0] < expr.length() && expr.charAt(pos[0]) == ' ') pos[0]++;
                if (pos[0] < expr.length() && expr.charAt(pos[0]) == '(') pos[0]++;
                double arg = parseSuma(expr, pos);
                if (pos[0] < expr.length() && expr.charAt(pos[0]) == ')') pos[0]++;
                switch (f) {
                    case "sin":   return Math.sin(arg);
                    case "cos":   return Math.cos(arg);
                    case "tan":   return Math.tan(arg);
                    case "sqrt":  return Math.sqrt(arg);
                    case "log":   return Math.log(arg);
                    case "log10": return Math.log10(arg);
                    case "exp":   return Math.exp(arg);
                    case "abs":   return Math.abs(arg);
                }
            }
        }
        
        int inicio = pos[0];
        while (pos[0] < expr.length() && (Character.isDigit(expr.charAt(pos[0])) || expr.charAt(pos[0]) == '.')) pos[0]++;
        if (pos[0] > inicio) return Double.parseDouble(expr.substring(inicio, pos[0]));
        
        throw new RuntimeException("Expresión inválida en posición " + pos[0]);
    }
}
