/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana informativa sobre el proyecto y sus autores.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class AcercaDe extends JFrame{
    ProyectoIntApp padre;
    JButton volver = new JButton("Volver");
    JButton salir = new JButton("Salir");

    /**
     * Constructor. Inicializa y muestra la ventana.
     *
     * @param padre ventana principal de la aplicación
     */
    public AcercaDe(ProyectoIntApp padre) {
        super("AcercaDe");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(20, 25, 40));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }
    
    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {
        JLabel titulo = new JLabel("ACERCA DEL PROYECTO");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(44, 62, 80));
        titulo.setForeground(new Color(255, 220, 50));
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);
        
        JLabel info = new JLabel("<html>Esta aplicación educativa de escritorio ha sido desarrollada en el lenguaje de programación Java con el objetivo de apoyar el aprendizaje en matemáticas, física, álgebra lineal y humanidades. Permite a los estudiantes resolver problemas de forma interactiva mediante una interfaz gráfica amigable.\n" +
                                 "\n" +
                                 "El proyecto fue realizado por estudiantes de Ingeniería de Sistemas (Santiago Pérez, Nicholas Siavichay, Samuel Arias, Jose Riascos) como parte del desarrollo académico en las asignaturas de Programación Orientada a Objetos, Matemáticas II, Física I, Álgebra Lineal, Teoría General de Sistemas y Humanidades.\n" +
                                 "\n" +
                                 "Año: 2026.</html>");
        info.setBounds(30, 110, 1000, 320);
        info.setHorizontalAlignment(JLabel.CENTER);
        info.setForeground(new Color(200, 210, 230));
        info.setFont(new Font("Arial", Font.ITALIC, 25));
        add(info);

        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);
        
        ProyectoIntApp.estilizarBoton(salir, new Color(192, 57, 43));
        salir.setBounds(838, 560, 150, 30);
        salir.setCursor(new Cursor(Cursor.HAND_CURSOR));
        salir.addActionListener((e) -> evento_salir());
        add(salir);
    }
        
    /**
     * Cierra esta ventana y vuelve al menú principal.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }
    
    /**
     * Solicita confirmación y cierra la aplicación si el usuario acepta.
     */
    public void evento_salir() {
        int respuesta = JOptionPane.showConfirmDialog(this, "¿Desea realmente salir de la aplicación?", "Confirmación", JOptionPane.YES_NO_OPTION);
        if(respuesta == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
}
