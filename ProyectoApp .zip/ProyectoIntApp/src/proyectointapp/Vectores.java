/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana para realizar operaciones con vectores en 2D y 3D.
 * Soporta suma, resta, producto punto, producto vectorial, módulo y ángulo.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class Vectores extends JFrame {
    Fisica padre;
    JButton volver   = new JButton("Volver");
    JButton limpiar  = new JButton("Limpiar");
    JButton calcular = new JButton("Calcular");
    JTextField ax = new JTextField(); JTextField ay = new JTextField(); JTextField az = new JTextField();
    JTextField bx = new JTextField(); JTextField by = new JTextField(); JTextField bz = new JTextField();
    JTextArea  res = new JTextArea();
    JComboBox<String> operacion = new JComboBox<>(new String[]{
        "Suma  (A + B)", "Resta (A - B)", "Producto punto  (A · B)",
        "Producto vectorial  (A × B)", "Módulo de A", "Módulo de B", "Ángulo entre A y B"
    });

    /**
     * Constructor. Inicializa y muestra la ventana de Vectores.
     *
     * @param padre ventana del menú de Física
     */
    public Vectores(Fisica padre) {
        super("Vectores");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(10, 40, 20));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {
        JLabel titulo = new JLabel("FÍSICA - VECTORES");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(39, 174, 96));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);

        String[] cols = {"", "X", "Y", "Z"};
        int[] cx = {60, 170, 270, 370};
        for (int i = 1; i < 4; i++) {
            JLabel lbl = new JLabel(cols[i], JLabel.CENTER);
            lbl.setBounds(cx[i], 90, 80, 25);
            lbl.setFont(new Font("Arial", Font.BOLD, 16));
            lbl.setForeground(new Color(180, 255, 180));
            add(lbl);
        }

        JLabel lblA = new JLabel("Vector A:");
        lblA.setBounds(60, 120, 100, 30);
        lblA.setFont(new Font("Arial", Font.BOLD, 16));
        lblA.setForeground(Color.WHITE);
        add(lblA);
        ax.setBounds(170, 120, 80, 30); add(ax);
        ay.setBounds(270, 120, 80, 30); add(ay);
        az.setBounds(370, 120, 80, 30); add(az);
        JLabel lblAz = new JLabel("(0 si es 2D)", JLabel.LEFT);
        lblAz.setBounds(460, 120, 120, 30);
        lblAz.setFont(new Font("Arial", Font.ITALIC, 13));
        lblAz.setForeground(new Color(150, 220, 150));
        add(lblAz);

        JLabel lblB = new JLabel("Vector B:");
        lblB.setBounds(60, 165, 100, 30);
        lblB.setFont(new Font("Arial", Font.BOLD, 16));
        lblB.setForeground(Color.WHITE);
        add(lblB);
        bx.setBounds(170, 165, 80, 30); add(bx);
        by.setBounds(270, 165, 80, 30); add(by);
        bz.setBounds(370, 165, 80, 30); add(bz);

        JLabel lblOp = new JLabel("Operación:");
        lblOp.setBounds(60, 215, 120, 30);
        lblOp.setFont(new Font("Arial", Font.BOLD, 16));
        lblOp.setForeground(Color.WHITE);
        add(lblOp);
        operacion.setBounds(190, 215, 280, 30);
        operacion.setFont(new Font("Arial", Font.PLAIN, 14));
        add(operacion);

        JLabel resu = new JLabel("Resultado:");
        resu.setBounds(60, 265, 300, 30);
        resu.setFont(new Font("Arial", Font.ITALIC, 22));
        resu.setForeground(new Color(255, 220, 80));
        add(resu);

        res.setBounds(60, 300, 880, 200);
        res.setEditable(false);
        res.setFont(new Font("Monospaced", Font.PLAIN, 15));
        res.setBackground(new Color(20, 60, 30));
        res.setForeground(new Color(200, 255, 200));
        res.setLineWrap(true);
        JScrollPane scroll = new JScrollPane(res);
        scroll.setBounds(60, 300, 880, 200);
        add(scroll);

        ProyectoIntApp.estilizarBoton(calcular, new Color(39, 174, 96));
        calcular.setBounds(490, 215, 120, 30);
        calcular.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calcular.addActionListener((e) -> evento_calcular());
        add(calcular);

        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);

        ProyectoIntApp.estilizarBoton(limpiar, new Color(22, 160, 133));
        limpiar.setBounds(190, 560, 150, 30);
        limpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        limpiar.addActionListener((e) -> evento_limpiar());
        add(limpiar);
    }

    /**
     * Cierra esta ventana y vuelve al menú de Física.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }

    /**
     * Borra los campos de los vectores y el resultado.
     */
    public void evento_limpiar() {
        ax.setText(""); ay.setText(""); az.setText("");
        bx.setText(""); by.setText(""); bz.setText("");
        res.setText("");
        ax.requestFocus();
    }

    /**
     * Lee los componentes de ambos vectores, ejecuta la operación seleccionada
     * y muestra el resultado en el área de texto.
     */
    public void evento_calcular() {
        try {
            double axV = parsear(ax.getText(), "Ax"), ayV = parsear(ay.getText(), "Ay"), azV = parsear(az.getText(), "Az (0 si es 2D)");
            double bxV = parsear(bx.getText(), "Bx"), byV = parsear(by.getText(), "By"), bzV = parsear(bz.getText(), "Bz (0 si es 2D)");
            int op = operacion.getSelectedIndex();
            StringBuilder sb = new StringBuilder();
            sb.append(String.format("A = (%.4f, %.4f, %.4f)\n", axV, ayV, azV));
            sb.append(String.format("B = (%.4f, %.4f, %.4f)\n\n", bxV, byV, bzV));

            switch (op) {
                case 0: { double rx=axV+bxV,ry=ayV+byV,rz=azV+bzV; sb.append(String.format("A + B = (%.4f, %.4f, %.4f)",rx,ry,rz)); sb.append(String.format("\n|A + B| = %.4f",Math.sqrt(rx*rx+ry*ry+rz*rz))); break; }
                case 1: { double rx=axV-bxV,ry=ayV-byV,rz=azV-bzV; sb.append(String.format("A - B = (%.4f, %.4f, %.4f)",rx,ry,rz)); sb.append(String.format("\n|A - B| = %.4f",Math.sqrt(rx*rx+ry*ry+rz*rz))); break; }
                case 2: { double dot=axV*bxV+ayV*byV+azV*bzV; sb.append(String.format("A · B = %.4f",dot)); sb.append("\n(Si A · B = 0, los vectores son perpendiculares)"); break; }
                case 3: { double rx=ayV*bzV-azV*byV,ry=azV*bxV-axV*bzV,rz2=axV*byV-ayV*bxV; sb.append(String.format("A × B = (%.4f, %.4f, %.4f)",rx,ry,rz2)); sb.append(String.format("\n|A × B| = %.4f",Math.sqrt(rx*rx+ry*ry+rz2*rz2))); sb.append("\n(El resultado es perpendicular al plano formado por A y B)"); break; }
                case 4: { double mod=Math.sqrt(axV*axV+ayV*ayV+azV*azV); sb.append(String.format("|A| = √(%.4f² + %.4f² + %.4f²) = %.4f",axV,ayV,azV,mod)); break; }
                case 5: { double mod=Math.sqrt(bxV*bxV+byV*byV+bzV*bzV); sb.append(String.format("|B| = √(%.4f² + %.4f² + %.4f²) = %.4f",bxV,byV,bzV,mod)); break; }
                case 6: {
                    double dot=axV*bxV+ayV*byV+azV*bzV, modA=Math.sqrt(axV*axV+ayV*ayV+azV*azV), modB=Math.sqrt(bxV*bxV+byV*byV+bzV*bzV);
                    if (modA==0||modB==0) { sb.append("Error: uno de los vectores es el vector nulo, ángulo indefinido."); }
                    else {
                        double cosTheta=Math.max(-1.0,Math.min(1.0,dot/(modA*modB))), angRad=Math.acos(cosTheta), angGrad=Math.toDegrees(angRad);
                        sb.append(String.format("cos(θ) = (A · B) / (|A| × |B|) = %.4f / (%.4f × %.4f) = %.4f",dot,modA,modB,cosTheta));
                        sb.append(String.format("\n\nÁngulo θ = %.4f rad  =  %.2f°",angRad,angGrad));
                    }
                    break;
                }
            }
            res.setText(sb.toString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Convierte el texto de un campo a double. Retorna 0 si está vacío.
     *
     * @param txt   texto del campo de texto
     * @param campo nombre del campo (para mensaje de error)
     * @return      valor numérico del campo
     * @throws RuntimeException si el texto no es un número válido
     */
    private double parsear(String txt, String campo) {
        txt = txt.trim();
        if (txt.isEmpty()) return 0.0;
        try { return Double.parseDouble(txt); }
        catch (NumberFormatException e) {
            throw new RuntimeException("El campo '" + campo + "' debe ser un número.\nEj: 3, -1.5, 0");
        }
    }
}
