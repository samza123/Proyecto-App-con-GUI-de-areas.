/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana para calcular límites de funciones f(x) cuando x tiende a un valor o al infinito.
 * Utiliza sustitución directa y aproximación numérica lateral.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class Limites extends JFrame {
    Matematicas padre;
    JButton volver = new JButton("Volver");
    JButton limpiar = new JButton("Limpiar");
    JButton calcular = new JButton("Calcular");
    JTextField limite = new JTextField();
    JTextField xTiende = new JTextField();
    JTextField res = new JTextField();

    /**
     * Constructor. Inicializa y muestra la ventana de Límites.
     *
     * @param padre ventana del menú de Matemáticas
     */
    public Limites(Matematicas padre) {
        super("Limites");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(10, 30, 60));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }
    
    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {
        JLabel titulo = new JLabel("MATEMÁTICAS - LÍMITES");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(41, 128, 185));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);
        
        JLabel datos = new JLabel("<html>lim f(x) = </html>");
        datos.setBounds(40, 100, 120, 30);
        datos.setFont(new Font("Arial", Font.ITALIC, 20));
        datos.setForeground(Color.WHITE);
        add(datos);
        
        JLabel ej_1 = new JLabel("<html>Ej: (3*x+1)/(x-4) | x^2-1 | sin(x)/x</html>");
        ej_1.setBounds(415, 100, 560, 30);
        ej_1.setFont(new Font("Arial", Font.ITALIC, 16));
        ej_1.setForeground(new Color(180, 210, 255));
        add(ej_1);
        
        limite.setBounds(160, 100, 245, 30);
        add(limite);
        
        JLabel x = new JLabel("<html>x → </html>");
        x.setBounds(50, 140, 100, 30);
        x.setFont(new Font("Arial", Font.ITALIC, 20));
        x.setForeground(Color.WHITE);
        add(x);
        
        JLabel x2 = new JLabel("<html>Ej: 4 | inf | -inf</html>");
        x2.setBounds(238, 140, 250, 30);
        x2.setFont(new Font("Arial", Font.ITALIC, 16));
        x2.setForeground(new Color(180, 210, 255));
        add(x2);
        
        xTiende.setBounds(100, 140, 120, 30);
        add(xTiende);
        
        JLabel resu = new JLabel("<html>Resultado:</html>");
        resu.setBounds(100, 230, 400, 30);
        resu.setFont(new Font("Arial", Font.ITALIC, 25));
        resu.setForeground(new Color(255, 220, 80));
        add(resu);
        
        res.setBounds(100, 270, 800, 150);
        res.setEditable(false);
        res.setFont(new Font("Monospaced", Font.PLAIN, 15));
        add(res);
        
        JLabel nota = new JLabel("<html><b>Operadores:</b> + - * / ^ | Funciones: sin, cos, tan, sqrt, log, exp, abs | Infinito: inf</html>");
        nota.setBounds(100, 430, 800, 25);
        nota.setFont(new Font("Arial", Font.PLAIN, 13));
        nota.setForeground(new Color(150, 200, 255));
        add(nota);
        
        ProyectoIntApp.estilizarBoton(calcular, new Color(41, 128, 185));
        calcular.setBounds(100, 180, 120, 30);
        calcular.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calcular.addActionListener((e) -> evento_calcular());
        add(calcular);
        
        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);

        ProyectoIntApp.estilizarBoton(limpiar, new Color(22, 160, 133));
        limpiar.setBounds(190, 560, 150, 30);
        limpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        limpiar.addActionListener((e) -> evento_limpiar());
        add(limpiar);
    }
    
    /**
     * Cierra esta ventana y vuelve al menú de Matemáticas.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }
    
    /**
     * Borra los campos de entrada y el resultado.
     */
    public void evento_limpiar() {
        limite.setText("");
        xTiende.setText("");
        res.setText("");
        limite.requestFocus();
    }
    
    /**
     * Calcula el límite de la función ingresada cuando x tiende al valor indicado.
     * Usa sustitución directa; si falla, aplica aproximación lateral.
     */
    public void evento_calcular() {
        String expr = limite.getText().trim();
        String xStr = xTiende.getText().trim().toLowerCase();
        
        if (expr.isEmpty() || xStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor ingresa la función y el valor al que tiende x.", "Datos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        try {
            boolean esInfinito = xStr.equals("inf") || xStr.equals("infinity") || xStr.equals("+inf");
            boolean esMenosInfinito = xStr.equals("-inf") || xStr.equals("-infinity");
            
            double xVal;
            String xDisplay;
            
            if (esInfinito) { xVal = Double.MAX_VALUE; xDisplay = "∞"; }
            else if (esMenosInfinito) { xVal = -Double.MAX_VALUE; xDisplay = "-∞"; }
            else { xVal = Double.parseDouble(xStr); xDisplay = xStr; }
            
            double directo = evaluarFuncion(expr, xVal);
            
            if (!Double.isNaN(directo) && !Double.isInfinite(directo)) {
                res.setText(String.format("lim   f(x)  =  %.6f\nx→%s\n\nMétodo: Sustitución directa  →  f(%s) = %.6f",
                    directo, xDisplay, xDisplay, directo));
            } else {
                double delta = 1e-7;
                double izq, der;
                if (esInfinito) { izq = evaluarFuncion(expr, 1e10); der = evaluarFuncion(expr, 1e15); }
                else if (esMenosInfinito) { izq = evaluarFuncion(expr, -1e15); der = evaluarFuncion(expr, -1e10); }
                else { izq = evaluarFuncion(expr, xVal - delta); der = evaluarFuncion(expr, xVal + delta); }
                
                boolean izqFinita = !Double.isNaN(izq) && !Double.isInfinite(izq);
                boolean derFinita = !Double.isNaN(der) && !Double.isInfinite(der);
                
                if (izqFinita && derFinita && Math.abs(izq - der) < 1e-4) {
                    double lim = (izq + der) / 2.0;
                    res.setText(String.format("lim   f(x)  ≈  %.6f\nx→%s\n\nMétodo: Aproximación numérica\n  Por izquierda: %.6f  |  Por derecha: %.6f",
                        lim, xDisplay, izq, der));
                } else if (!izqFinita && !derFinita) {
                    String signo = (izq > 0 || der > 0) ? "+∞" : "-∞";
                    res.setText(String.format("lim   f(x)  =  %s\nx→%s\n\nLa función diverge hacia el infinito.", signo, xDisplay));
                } else {
                    res.setText(String.format("lim   f(x)  No existe\nx→%s\n\nLímite lateral izquierdo: %s\nLímite lateral derecho:   %s\n(Los límites laterales son distintos o indefinidos)",
                        xDisplay,
                        izqFinita ? String.format("%.6f", izq) : (izq > 0 ? "+∞" : "-∞"),
                        derFinita ? String.format("%.6f", der) : (der > 0 ? "+∞" : "-∞")));
                }
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "El valor de x debe ser un número, 'inf' o '-inf'.\nEj: 4, -2, inf, -inf", "Valor inválido", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al evaluar el límite:\n" + e.getMessage() +
                "\n\nVerifica la sintaxis. Usa * para multiplicar.\nEj: (3*x+1)/(x-4)", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Sustituye x en la expresión y la evalúa numéricamente.
     *
     * @param expr expresión matemática como cadena
     * @param x    valor numérico de x
     * @return     resultado de evaluar la expresión
     */
    private double evaluarFuncion(String expr, double x) {
        String e = expr.toLowerCase().trim();
        e = e.replace("pi", String.valueOf(Math.PI));
        e = e.replaceAll("(?<![a-z])e(?![a-z])", String.valueOf(Math.E));
        e = e.replace("x", "(" + x + ")");
        return evaluarExpresion(e);
    }
    
    /**
     * Inicia el análisis recursivo de la expresión.
     *
     * @param expr expresión preprocesada
     * @return     valor numérico resultante
     */
    private double evaluarExpresion(String expr) { return parseSuma(expr.trim(), new int[]{0}); }
    
    private double parseSuma(String expr, int[] pos) {
        double r = parseMultiplica(expr, pos);
        while (pos[0] < expr.length()) {
            char c = expr.charAt(pos[0]);
            if (c == '+') { pos[0]++; r += parseMultiplica(expr, pos); }
            else if (c == '-') { pos[0]++; r -= parseMultiplica(expr, pos); }
            else break;
        }
        return r;
    }
    
    private double parseMultiplica(String expr, int[] pos) {
        double r = parsePotencia(expr, pos);
        while (pos[0] < expr.length()) {
            char c = expr.charAt(pos[0]);
            if (c == '*') { pos[0]++; r *= parsePotencia(expr, pos); }
            else if (c == '/') { pos[0]++; r /= parsePotencia(expr, pos); }
            else break;
        }
        return r;
    }
    
    private double parsePotencia(String expr, int[] pos) {
        double base = parseUnario(expr, pos);
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '^') { pos[0]++; return Math.pow(base, parseUnario(expr, pos)); }
        return base;
    }
    
    private double parseUnario(String expr, int[] pos) {
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '-') { pos[0]++; return -parsePrimario(expr, pos); }
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '+') { pos[0]++; }
        return parsePrimario(expr, pos);
    }
    
    private double parsePrimario(String expr, int[] pos) {
        while (pos[0] < expr.length() && expr.charAt(pos[0]) == ' ') pos[0]++;
        if (pos[0] < expr.length() && expr.charAt(pos[0]) == '(') {
            pos[0]++; double val = parseSuma(expr, pos);
            if (pos[0] < expr.length() && expr.charAt(pos[0]) == ')') pos[0]++;
            return val;
        }
        String[] fns = {"sin", "cos", "tan", "sqrt", "log10", "log", "exp", "abs"};
        for (String f : fns) {
            if (expr.startsWith(f, pos[0])) {
                pos[0] += f.length();
                while (pos[0] < expr.length() && expr.charAt(pos[0]) == ' ') pos[0]++;
                if (pos[0] < expr.length() && expr.charAt(pos[0]) == '(') pos[0]++;
                double arg = parseSuma(expr, pos);
                if (pos[0] < expr.length() && expr.charAt(pos[0]) == ')') pos[0]++;
                switch (f) {
                    case "sin":   return Math.sin(arg);
                    case "cos":   return Math.cos(arg);
                    case "tan":   return Math.tan(arg);
                    case "sqrt":  return Math.sqrt(arg);
                    case "log":   return Math.log(arg);
                    case "log10": return Math.log10(arg);
                    case "exp":   return Math.exp(arg);
                    case "abs":   return Math.abs(arg);
                }
            }
        }
        int ini = pos[0];
        while (pos[0] < expr.length() && (Character.isDigit(expr.charAt(pos[0])) || expr.charAt(pos[0]) == '.')) pos[0]++;
        if (pos[0] > ini) return Double.parseDouble(expr.substring(ini, pos[0]));
        throw new RuntimeException("Expresión inválida en posición " + pos[0] + ": '" + expr.substring(pos[0]) + "'");
    }
}
