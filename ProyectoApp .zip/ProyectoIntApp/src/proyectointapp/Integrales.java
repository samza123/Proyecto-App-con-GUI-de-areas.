/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana para calcular integrales indefinidas y definidas de f(x).
 * Usa la regla de Simpson para integrales definidas y un motor simbólico para indefinidas.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class Integrales extends JFrame {

    // ─── Colores ────────────────────────────────────────────────────────
    private static final Color C_FONDO    = new Color(18,  32,  60);
    private static final Color C_PANEL    = new Color(28,  48,  90);
    private static final Color C_ACENTO   = new Color(52, 152, 219);
    private static final Color C_VERDE    = new Color(46, 204, 113);
    private static final Color C_TEXTO    = new Color(236, 240, 241);
    private static final Color C_GRIS     = new Color(149, 165, 166);
    private static final Color C_CAMPO    = new Color(44,  62,  80);
    private static final Color C_RESF     = new Color(12,  24,  48);

    Matematicas padre;
    JComboBox<String> tipoIntegral;
    JTextField funcion, limInf, limSup, res;
    JLabel lblInf, lblSup, lblEj;
    JButton calcular, limpiar, volver;

    /**
     * Constructor. Inicializa y muestra la ventana de Integrales.
     *
     * @param padre ventana del menú de Matemáticas
     */
    public Integrales(Matematicas padre) {
        super("Integrales");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(C_FONDO);
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    // ═══════════════════════════ GUI ════════════════════════════════════
    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {

        // Título
        JPanel pTitulo = new JPanel(null);
        pTitulo.setBounds(0, 0, 1024, 68);
        pTitulo.setBackground(C_PANEL);
        pTitulo.setBorder(BorderFactory.createMatteBorder(0, 0, 3, 0, C_ACENTO));
        JLabel titulo = new JLabel("\u222B  MATEMÁTICAS — INTEGRALES");
        titulo.setBounds(0, 0, 1024, 68);
        titulo.setForeground(C_TEXTO);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 32));
        pTitulo.add(titulo);
        add(pTitulo);

        // Panel central
        JPanel panel = new JPanel(null);
        panel.setBounds(30, 88, 960, 435);
        panel.setBackground(C_PANEL);
        panel.setBorder(BorderFactory.createLineBorder(C_ACENTO, 1, true));
        add(panel);

        int px = 28;

        // Tipo
        lbl(panel, "Tipo de integral:", px, 18, 14, Font.BOLD);
        tipoIntegral = new JComboBox<>(new String[]{"Indefinida", "Definida"});
        tipoIntegral.setBounds(px + 168, 18, 155, 28);
        estilizarCombo(tipoIntegral);
        tipoIntegral.addActionListener(e -> actualizarUI());
        panel.add(tipoIntegral);

        // Función
        JLabel lFx = lbl(panel, "\u222B  f(x) dx", px, 66, 20, Font.ITALIC);
        lFx.setForeground(C_ACENTO);
        funcion = campo();
        funcion.setBounds(px + 130, 64, 320, 32);
        panel.add(funcion);
        lblEj = lbl(panel, "Ej: x^2 + 3*x + sqrt(x)", px + 462, 66, 13, Font.ITALIC);
        lblEj.setForeground(C_GRIS);

        // Sintaxis
        JLabel lSin = lbl(panel,
            "Sintaxis:  x^2  |  sqrt(x)  |  x^(1/3)  |  sin(x)  |  cos(x)  |  tan(x)  |  exp(x)  |  log(x)  |  constante",
            px, 106, 12, Font.PLAIN);
        lSin.setForeground(C_GRIS);

        // Límites
        lblInf = lbl(panel, "Límite inferior  a =", px, 143, 14, Font.ITALIC);
        limInf = campo(); limInf.setBounds(px + 185, 141, 100, 28); panel.add(limInf);
        lblSup = lbl(panel, "Límite superior  b =", px, 183, 14, Font.ITALIC);
        limSup = campo(); limSup.setBounds(px + 185, 181, 100, 28); panel.add(limSup);
        lblInf.setVisible(false); limInf.setVisible(false);
        lblSup.setVisible(false); limSup.setVisible(false);

        // Botón calcular
        calcular = boton("Calcular  \u25B6", new Color(41, 128, 185), new Color(52, 152, 219));
        calcular.setBounds(px, 228, 165, 38);
        calcular.addActionListener(e -> evento_calcular());
        panel.add(calcular);

        // Separador
        JSeparator sep = new JSeparator();
        sep.setBounds(px, 282, 900, 2);
        sep.setForeground(C_ACENTO); sep.setBackground(C_ACENTO);
        panel.add(sep);

        // Resultado
        JLabel lRes = lbl(panel, "Resultado:", px, 292, 18, Font.BOLD);
        lRes.setForeground(C_VERDE);
        res = new JTextField();
        res.setBounds(px, 326, 900, 72);
        res.setEditable(false);
        res.setFont(new Font("Monospaced", Font.BOLD, 16));
        res.setBackground(C_RESF);
        res.setForeground(C_VERDE);
        res.setCaretColor(C_VERDE);
        res.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_VERDE, 2, true),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)));
        panel.add(res);

        // Botones inferiores
        volver = boton("\u25C4  Volver", new Color(80, 90, 110), new Color(110, 120, 140));
        volver.setBounds(30, 543, 155, 35);
        volver.addActionListener(e -> evento_volver());
        add(volver);

        limpiar = boton("\u2715  Limpiar", new Color(39, 120, 80), new Color(46, 160, 100));
        limpiar.setBounds(200, 543, 155, 35);
        limpiar.addActionListener(e -> evento_limpiar());
        add(limpiar);

        // Footer
        JLabel footer = new JLabel("Indefinida: resultado simbólico   |   Definida: integración numérica de alta precisión");
        footer.setBounds(0, 608, 1024, 20);
        footer.setForeground(C_GRIS);
        footer.setFont(new Font("Arial", Font.ITALIC, 11));
        footer.setHorizontalAlignment(JLabel.CENTER);
        add(footer);
    }

    // ── helpers ─────────────────────────────────────────────────────────
    private JLabel lbl(JPanel p, String txt, int x, int y, int sz, int style) {
        JLabel l = new JLabel(txt);
        l.setBounds(x, y, 900, 28);
        l.setForeground(C_TEXTO);
        l.setFont(new Font("Arial", style, sz));
        p.add(l);
        return l;
    }

    private JTextField campo() {
        JTextField tf = new JTextField();
        tf.setBackground(C_CAMPO);
        tf.setForeground(C_TEXTO);
        tf.setCaretColor(C_ACENTO);
        tf.setFont(new Font("Monospaced", Font.PLAIN, 15));
        tf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(C_ACENTO, 1, true),
            BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        return tf;
    }

    private JButton boton(String txt, Color bg, Color hover) {
        JButton b = new JButton(txt);
        b.setBackground(bg); b.setForeground(C_TEXTO);
        b.setFont(new Font("Arial", Font.BOLD, 14));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        b.setOpaque(true);
        b.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent e) { b.setBackground(hover); }
            public void mouseExited(java.awt.event.MouseEvent e)  { b.setBackground(bg); }
        });
        return b;
    }

    private void estilizarCombo(JComboBox<String> cb) {
        cb.setBackground(C_CAMPO); cb.setForeground(C_TEXTO);
        cb.setFont(new Font("Arial", Font.PLAIN, 14));
        cb.setBorder(BorderFactory.createLineBorder(C_ACENTO, 1));
        cb.setCursor(new Cursor(Cursor.HAND_CURSOR));
        cb.setRenderer(new DefaultListCellRenderer() {
            public Component getListCellRendererComponent(JList<?> list, Object val,
                    int idx, boolean sel, boolean focus) {
                super.getListCellRendererComponent(list, val, idx, sel, focus);
                setBackground(sel ? C_ACENTO : C_CAMPO);
                setForeground(C_TEXTO);
                return this;
            }
        });
    }

    //EVENTOS
    /**
     * Muestra u oculta los campos de límites según el tipo de integral seleccionado.
     */
    public void actualizarUI() {
        boolean def = "Definida".equals(tipoIntegral.getSelectedItem());
        lblInf.setVisible(def); limInf.setVisible(def);
        lblSup.setVisible(def); limSup.setVisible(def);
        lblEj.setText(def ? "Ej: x^2 + 2*x + 1  (a=4, b=3)"
                          : "Ej: x^2 + 3*x + sqrt(x)");
        revalidate(); repaint();
    }

    /**
     * Lee la función y los parámetros, calcula la integral y muestra el resultado.
     */
    public void evento_calcular() {
        String expr = funcion.getText().trim();
        if (expr.isEmpty()) { aviso("Por favor ingresa una función f(x)."); return; }
        boolean def = "Definida".equals(tipoIntegral.getSelectedItem());
        try {
            if (def) {
                String aS = limInf.getText().trim(), bS = limSup.getText().trim();
                if (aS.isEmpty() || bS.isEmpty()) { aviso("Ingresa los límites a y b."); return; }
                double a = Double.parseDouble(aS), b = Double.parseDouble(bS);
                double r = simpson(expr, a, b, 6000);
                res.setText("  \u222B[" + aS + " \u2192 " + bS + "]  ( " + expr + " ) dx   \u2248   " + String.format("%.8f", r));
            } else {
                String r = integralSimbolica(expr);
                res.setText("  \u222B ( " + expr + " ) dx   =   " + r + "   + C");
            }
        } catch (NumberFormatException ex) {
            aviso("Los límites deben ser números (usa punto decimal, ej: 1.5).");
        } catch (Exception ex) {
            aviso(ex.getMessage());
        }
    }

    /**
     * Cierra esta ventana y vuelve al menú de Matemáticas.
     */
    public void evento_volver() {
        setVisible(false); dispose(); padre.setVisible(true);
    }

    /**
     * Borra los campos de entrada y el resultado.
     */
    public void evento_limpiar() {
        funcion.setText(""); limInf.setText(""); limSup.setText(""); res.setText("");
        funcion.requestFocus();
    }

    private void aviso(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Aviso", JOptionPane.WARNING_MESSAGE);
    }

    // ═══════════════════ INTEGRACIÓN NUMÉRICA ═══════════════════════════
    /**
     * Calcula la integral definida usando la regla de Simpson compuesta.
     *
     * @param expr expresión de la función como cadena
     * @param a    límite inferior de integración
     * @param b    límite superior de integración
     * @param n    número de subintervalos (se ajusta a par automáticamente)
     * @return     valor aproximado de la integral
     * @throws Exception si la función no puede evaluarse
     */
    private double simpson(String expr, double a, double b, int n) throws Exception {
        if (n % 2 != 0) n++;
        double h = (b - a) / n;
        double suma = evaluar(expr, a) + evaluar(expr, b);
        for (int i = 1; i < n; i++)
            suma += ((i % 2 == 0) ? 2 : 4) * evaluar(expr, a + i * h);
        return (h / 3.0) * suma;
    }

    // ═══════════════════ EVALUADOR (PARSER RECURSIVO) ═══════════════════
    private double evaluar(String expr, double x) throws Exception {
        String e = expr
            .replaceAll("\\s+", "")
            .replace("sen(", "sin(")
            .replace("ln(", "log(")
            .replace("**", "^");
        // Reemplazar x por su valor (solo cuando no es parte de otra letra)
        String xv = (x < 0) ? "(" + x + ")" : Double.toString(x);
        e = e.replaceAll("(?<![A-Za-z])x(?![A-Za-z])", xv);
        // Multiplicación implícita: 2( → 2*(   y )( → )*(
        e = e.replaceAll("([0-9\\.)])([(A-Za-z])", "$1*$2");
        return new MathParser(e).expr();
    }

    // ─── MathParser ─────────────────────────────────────────────────────
    private static class MathParser {
        final char[] c;
        int i = 0;
        MathParser(String s) { c = s.toCharArray(); }

        double expr() throws Exception {
            double v = term();
            while (i < c.length && (c[i] == '+' || c[i] == '-')) {
                char op = c[i++]; double t = term();
                v = (op == '+') ? v + t : v - t;
            }
            return v;
        }
        double term() throws Exception {
            double v = pow();
            while (i < c.length && (c[i] == '*' || c[i] == '/')) {
                char op = c[i++]; double t = pow();
                v = (op == '*') ? v * t : v / t;
            }
            return v;
        }
        double pow() throws Exception {
            double base = unary();
            if (i < c.length && c[i] == '^') { i++; return Math.pow(base, unary()); }
            return base;
        }
        double unary() throws Exception {
            if (i < c.length && c[i] == '-') { i++; return -primary(); }
            if (i < c.length && c[i] == '+') { i++; }
            return primary();
        }
        double primary() throws Exception {
            if (i < c.length && c[i] == '(') {
                i++; double v = expr();
                if (i < c.length && c[i] == ')') i++;
                return v;
            }
            if (i < c.length && (Character.isDigit(c[i]) || c[i] == '.')) return num();
            if (i < c.length && Character.isLetter(c[i])) return func();
            throw new Exception("Token inesperado: '" + (i < c.length ? c[i] : '?') + "' — revisa la sintaxis.");
        }
        double num() {
            int s = i;
            while (i < c.length && (Character.isDigit(c[i]) || c[i] == '.' || c[i] == 'E' || c[i] == 'e'
                || ((c[i]=='-'||c[i]=='+') && i>0 && (c[i-1]=='E'||c[i-1]=='e')))) i++;
            return Double.parseDouble(new String(c, s, i - s));
        }
        double func() throws Exception {
            int s = i;
            while (i < c.length && Character.isLetter(c[i])) i++;
            String name = new String(c, s, i - s);
            if (i < c.length && c[i] == '(') {
                i++; double a = expr();
                if (i < c.length && c[i] == ')') i++;
                switch (name) {
                    case "sqrt": return Math.sqrt(a);
                    case "sin":  return Math.sin(a);
                    case "cos":  return Math.cos(a);
                    case "tan":  return Math.tan(a);
                    case "asin": return Math.asin(a);
                    case "acos": return Math.acos(a);
                    case "atan": return Math.atan(a);
                    case "log":  return Math.log(a);
                    case "log10":return Math.log10(a);
                    case "exp":  return Math.exp(a);
                    case "abs":  return Math.abs(a);
                    case "sinh": return Math.sinh(a);
                    case "cosh": return Math.cosh(a);
                    case "tanh": return Math.tanh(a);
                    default: throw new Exception("Función desconocida: '" + name + "'");
                }
            }
            // Constante sola (pi, e ya reemplazadas antes)
            throw new Exception("Símbolo no reconocido: '" + name + "'. ¿Falta paréntesis? Ej: sin(x)");
        }
    }

    // ═══════════════════ INTEGRACIÓN SIMBÓLICA ══════════════════════════
    /**
     * Calcula la integral indefinida de forma simbólica término a término.
     *
     * @param expr expresión de la función como cadena
     * @return     cadena con la antiderivada simbólica
     * @throws Exception si algún término no puede integrarse simbólicamente
     */
    private String integralSimbolica(String expr) throws Exception {
        String e = expr.trim().replace("**","^").replace("sen(","sin(").replace("ln(","log(");
        java.util.List<String> terminos = separarTerminos(e);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < terminos.size(); i++) {
            String t = terminos.get(i).trim();
            if (t.isEmpty()) continue;
            String it = integrarTermino(t);
            if (i == 0) sb.append(it);
            else if (it.startsWith("-")) sb.append(" - ").append(it.substring(1));
            else sb.append(" + ").append(it);
        }
        return sb.toString();
    }

    /** Separa la expresión en términos respetando paréntesis. */
    private java.util.List<String> separarTerminos(String expr) {
        java.util.List<String> list = new java.util.ArrayList<>();
        int depth = 0, ini = 0;
        for (int i = 0; i < expr.length(); i++) {
            char ch = expr.charAt(i);
            if (ch == '(') depth++;
            else if (ch == ')') depth--;
            else if ((ch == '+' || ch == '-') && depth == 0 && i > 0) {
                list.add(expr.substring(ini, i)); ini = i;
            }
        }
        list.add(expr.substring(ini));
        return list;
    }

    private String integrarTermino(String t) throws Exception {
        t = t.trim();
        double sign = 1.0;
        if (t.startsWith("-")) { sign = -1.0; t = t.substring(1).trim(); }
        else if (t.startsWith("+")) { t = t.substring(1).trim(); }

        // Coeficiente: "3*f(x)" o "3f(x)" o "2.5*x"
        double coef = sign;
        java.util.regex.Matcher mc = java.util.regex.Pattern
            .compile("^([0-9]*\\.?[0-9]+)\\*?(.+)$").matcher(t);
        if (mc.matches() && !mc.group(2).trim().isEmpty()) {
            coef = sign * Double.parseDouble(mc.group(1));
            t = mc.group(2).trim();
        }

        // Funciones trigonométricas y trascendentes
        if (t.equals("sin(x)"))  return fmtT(coef, "-cos(x)");
        if (t.equals("cos(x)"))  return fmtT(coef, "sin(x)");
        if (t.equals("tan(x)"))  return fmtT(coef, "-ln|cos(x)|");
        if (t.equals("exp(x)"))  return fmtT(coef, "exp(x)");
        if (t.equals("log(x)"))  return fmtT(coef, "x\u00B7ln(x) - x");
        if (t.equals("sqrt(x)") || t.equals("x^(1/2)")) return fmtT(coef, "(2/3)\u00B7x^(3/2)");
        if (t.equals("x"))       return fmtT(coef, "(1/2)\u00B7x\u00B2");

        // Constante pura
        if (!t.contains("x")) {
            try { return fmtNum(coef * Double.parseDouble(t)) + "x"; }
            catch (NumberFormatException ignored) {}
        }

        // x^n  (entero o decimal)
        java.util.regex.Matcher mp = java.util.regex.Pattern
            .compile("^x\\^(-?[0-9]+\\.?[0-9]*)$").matcher(t);
        if (mp.matches()) {
            double n = Double.parseDouble(mp.group(1));
            if (n == -1) return fmtT(coef, "ln|x|");
            double n1 = n + 1;
            return fmtNum(coef / n1) + "\u00B7x^" + fmtExp(n1);
        }

        // x^(a/b)
        java.util.regex.Matcher mf = java.util.regex.Pattern
            .compile("^x\\^\\((-?[0-9]+\\.?[0-9]*)/([0-9]+\\.?[0-9]*)\\)$").matcher(t);
        if (mf.matches()) {
            double num = Double.parseDouble(mf.group(1));
            double den = Double.parseDouble(mf.group(2));
            if (num / den == -1) return fmtT(coef, "ln|x|");
            double newNum = num + den;
            double n1 = (num + den) / den;
            return fmtNum(coef / n1) + "\u00B7x^(" + fmtExp(newNum) + "/" + fmtExp(den) + ")";
        }

        throw new Exception("No se pudo integrar simbólicamente: '" + t + "'.\n"
            + "Usa el modo Definida para obtener el valor numérico.");
    }

    private String fmtT(double c, String expr) {
        if (c == 1.0)  return expr;
        if (c == -1.0) return "-" + expr;
        return fmtNum(c) + "\u00B7(" + expr + ")";
    }

    private String fmtNum(double v) {
        if (v == (long) v) return String.valueOf((long) v);
        for (int d = 2; d <= 24; d++) {
            double n = v * d;
            if (Math.abs(n - Math.round(n)) < 1e-9) {
                long ni = Math.round((long)(v * d));
                long g  = mcd(Math.abs(ni), d);
                if (ni / g == d / g) return "1";
                return (ni / g) + "/" + (d / g);
            }
        }
        return String.format("%.5f", v).replaceAll("0+$","").replaceAll("\\.$","");
    }

    private String fmtExp(double n) {
        if (n == (long) n) return String.valueOf((long) n);
        return String.valueOf(n);
    }

    private long mcd(long a, long b) { return b == 0 ? a : mcd(b, a % b); }
}
