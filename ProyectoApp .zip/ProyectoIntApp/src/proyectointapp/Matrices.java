/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana para realizar operaciones con matrices cuadradas de 2×2 o 3×3.
 * Soporta suma, resta, multiplicación, transpuesta y determinante.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class Matrices extends JFrame {

    Fisica padre;
    JButton volver   = new JButton("Volver");
    JButton limpiar  = new JButton("Limpiar");
    JButton calcular = new JButton("Calcular");

    // Matriz A (3x3)
    JTextField[][] matA = new JTextField[3][3];
    // Matriz B (3x3)
    JTextField[][] matB = new JTextField[3][3];
    // Tamaño
    JComboBox<String> tamano = new JComboBox<>(new String[]{"2×2", "3×3"});
    // Operación
    JComboBox<String> operacion = new JComboBox<>(new String[]{
        "Suma  (A + B)",
        "Resta (A - B)",
        "Multiplicación  (A × B)",
        "Transpuesta de A",
        "Determinante de A"
    });
    // Resultado
    JTextArea res = new JTextArea();

    /**
     * Constructor. Inicializa y muestra la ventana de Matrices.
     *
     * @param padre ventana del menú de Física
     */
    public Matrices(Fisica padre) {
        super("Matrices");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(10, 40, 20));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {

        JLabel titulo = new JLabel("FÍSICA - MATRICES");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(39, 174, 96));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);

        // ── Tamaño ────────────────────────────────────────────────────────
        JLabel lblTam = new JLabel("Tamaño:");
        lblTam.setBounds(30, 80, 90, 25);
        lblTam.setFont(new Font("Arial", Font.BOLD, 15));
        lblTam.setForeground(Color.WHITE);
        add(lblTam);

        tamano.setBounds(120, 80, 90, 25);
        tamano.setFont(new Font("Arial", Font.PLAIN, 14));
        tamano.addActionListener((e) -> actualizarTamano());
        add(tamano);

        JLabel lblOp = new JLabel("Operación:");
        lblOp.setBounds(225, 80, 110, 25);
        lblOp.setFont(new Font("Arial", Font.BOLD, 15));
        lblOp.setForeground(Color.WHITE);
        add(lblOp);

        operacion.setBounds(335, 80, 250, 25);
        operacion.setFont(new Font("Arial", Font.PLAIN, 14));
        add(operacion);

        ProyectoIntApp.estilizarBoton(calcular, new Color(39, 174, 96));
        calcular.setBounds(600, 80, 120, 25);
        calcular.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calcular.addActionListener((e) -> evento_calcular());
        add(calcular);

        // ── Labels de matrices ────────────────────────────────────────────
        JLabel lblA = new JLabel("Matriz A");
        lblA.setBounds(60, 118, 200, 25);
        lblA.setFont(new Font("Arial", Font.BOLD, 15));
        lblA.setForeground(new Color(180, 255, 180));
        add(lblA);

        JLabel lblB = new JLabel("Matriz B");
        lblB.setBounds(420, 118, 200, 25);
        lblB.setFont(new Font("Arial", Font.BOLD, 15));
        lblB.setForeground(new Color(180, 255, 180));
        add(lblB);

        // ── Celdas de matrices ────────────────────────────────────────────
        int cellW = 55, cellH = 28, gapX = 10, gapY = 8;
        int startAx = 60,  startAy = 145;
        int startBx = 420, startBy = 145;

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matA[i][j] = new JTextField("0");
                matA[i][j].setBounds(startAx + j*(cellW+gapX), startAy + i*(cellH+gapY), cellW, cellH);
                matA[i][j].setHorizontalAlignment(JTextField.CENTER);
                add(matA[i][j]);

                matB[i][j] = new JTextField("0");
                matB[i][j].setBounds(startBx + j*(cellW+gapX), startBy + i*(cellH+gapY), cellW, cellH);
                matB[i][j].setHorizontalAlignment(JTextField.CENTER);
                add(matB[i][j]);
            }
        }

        // ── Resultado ─────────────────────────────────────────────────────
        JLabel resu = new JLabel("Resultado:");
        resu.setBounds(60, 285, 300, 28);
        resu.setFont(new Font("Arial", Font.ITALIC, 20));
        resu.setForeground(new Color(255, 220, 80));
        add(resu);

        res.setBounds(60, 318, 880, 200);
        res.setEditable(false);
        res.setFont(new Font("Monospaced", Font.PLAIN, 14));
        res.setBackground(new Color(20, 60, 30));
        res.setForeground(new Color(200, 255, 200));
        res.setLineWrap(false);
        JScrollPane scroll = new JScrollPane(res);
        scroll.setBounds(60, 318, 880, 200);
        add(scroll);

        // ── Botones ───────────────────────────────────────────────────────
        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(20, 560, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);

        ProyectoIntApp.estilizarBoton(limpiar, new Color(22, 160, 133));
        limpiar.setBounds(190, 560, 150, 30);
        limpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        limpiar.addActionListener((e) -> evento_limpiar());
        add(limpiar);

        actualizarTamano();
    }

    /**
     * Muestra u oculta la tercera fila/columna según el tamaño seleccionado (2×2 o 3×3).
     */
    private void actualizarTamano() {
        boolean es3x3 = tamano.getSelectedIndex() == 1;
        // Mostrar/ocultar fila y columna 3
        for (int i = 0; i < 3; i++) {
            matA[i][2].setVisible(es3x3);
            matA[2][i].setVisible(es3x3);
            matB[i][2].setVisible(es3x3);
            matB[2][i].setVisible(es3x3);
        }
    }

    /**
     * Cierra esta ventana y vuelve al menú de Física.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }

    /**
     * Restablece todas las celdas de las matrices a cero y limpia el resultado.
     */
    public void evento_limpiar() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) {
                matA[i][j].setText("0");
                matB[i][j].setText("0");
            }
        res.setText("");
        matA[0][0].requestFocus();
    }

    /**
     * Lee las matrices, ejecuta la operación seleccionada y muestra el resultado.
     */
    public void evento_calcular() {
        try {
            int n = tamano.getSelectedIndex() == 0 ? 2 : 3;
            double[][] A = leerMatriz(matA, n);
            double[][] B = leerMatriz(matB, n);
            int op = operacion.getSelectedIndex();
            StringBuilder sb = new StringBuilder();

            sb.append("Matriz A:\n").append(matrizStr(A, n)).append("\n");
            if (op < 3) sb.append("Matriz B:\n").append(matrizStr(B, n)).append("\n");
            sb.append("\n");

            switch (op) {
                case 0: { // Suma
                    double[][] R = new double[n][n];
                    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) R[i][j] = A[i][j] + B[i][j];
                    sb.append("A + B =\n").append(matrizStr(R, n));
                    break;
                }
                case 1: { // Resta
                    double[][] R = new double[n][n];
                    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) R[i][j] = A[i][j] - B[i][j];
                    sb.append("A - B =\n").append(matrizStr(R, n));
                    break;
                }
                case 2: { // Multiplicación
                    double[][] R = new double[n][n];
                    for (int i = 0; i < n; i++)
                        for (int j = 0; j < n; j++)
                            for (int k = 0; k < n; k++)
                                R[i][j] += A[i][k] * B[k][j];
                    sb.append("A × B =\n").append(matrizStr(R, n));
                    break;
                }
                case 3: { // Transpuesta de A
                    double[][] R = new double[n][n];
                    for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) R[i][j] = A[j][i];
                    sb.append("Transpuesta de A =\n").append(matrizStr(R, n));
                    break;
                }
                case 4: { // Determinante
                    double det = (n == 2) ? det2(A) : det3(A);
                    sb.append(String.format("det(A) = %.4f", det));
                    if (n == 2) {
                        sb.append(String.format("\n\nCálculo: (%.2f × %.2f) - (%.2f × %.2f)",
                            A[0][0], A[1][1], A[0][1], A[1][0]));
                    }
                    if (Math.abs(det) < 1e-9) sb.append("\n\n⚠ La matriz es singular (det = 0), no tiene inversa.");
                    else sb.append("\n\nLa matriz es invertible.");
                    break;
                }
            }
            res.setText(sb.toString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Lee los valores de una matriz desde los campos de texto.
     *
     * @param m arreglo de JTextField con los valores de la matriz
     * @param n tamaño de la matriz (2 o 3)
     * @return  matriz numérica de tamaño n×n
     * @throws RuntimeException si algún campo contiene un valor no numérico
     */
    private double[][] leerMatriz(JTextField[][] m, int n) {
        double[][] mat = new double[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++) {
                String txt = m[i][j].getText().trim();
                if (txt.isEmpty()) txt = "0";
                try { mat[i][j] = Double.parseDouble(txt); }
                catch (NumberFormatException e) {
                    throw new RuntimeException("Valor inválido en fila " + (i+1) + " col " + (j+1) + ": '" + txt + "'");
                }
            }
        return mat;
    }

    /**
     * Convierte una matriz en cadena formateada para mostrar en pantalla.
     *
     * @param m matriz a convertir
     * @param n tamaño de la matriz
     * @return  representación textual de la matriz
     */
    private String matrizStr(double[][] m, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append("  [ ");
            for (int j = 0; j < n; j++) sb.append(String.format("%9.4f  ", m[i][j]));
            sb.append("]\n");
        }
        return sb.toString();
    }

    /**
     * Calcula el determinante de una matriz 2×2.
     *
     * @param m matriz 2×2
     * @return  determinante
     */
    private double det2(double[][] m) {
        return m[0][0]*m[1][1] - m[0][1]*m[1][0];
    }

    /**
     * Calcula el determinante de una matriz 3×3 por cofactores.
     *
     * @param m matriz 3×3
     * @return  determinante
     */
    private double det3(double[][] m) {
        return m[0][0]*(m[1][1]*m[2][2] - m[1][2]*m[2][1])
             - m[0][1]*(m[1][0]*m[2][2] - m[1][2]*m[2][0])
             + m[0][2]*(m[1][0]*m[2][1] - m[1][1]*m[2][0]);
    }
}
