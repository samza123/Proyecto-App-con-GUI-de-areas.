/**
 * Aplicación educativa para ayudar a los estudiantes en distintas áreas de conocimiento
 * Autor 1: Santiago Pérez Bastidas - 230252038
 * Autor 2: Nicholas Alberto Siavichay Ocampo - 230252027
 * Autor 3: Samuel Felipe Arias Flechas - 230252026
 * Autor 4: Jose Alberto Riascos Ruiz - 230252048
 * Versión: 1.0
 */
package proyectointapp;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 * Ventana para resolver sistemas de ecuaciones lineales mediante el método Gauss-Jordan.
 * Soporta de 2 a 5 ecuaciones, muestra el proceso paso a paso y verifica la solución.
 *
 * @author Santiago Pérez Bastidas
 * @author Nicholas Alberto Siavichay Ocampo
 * @author Samuel Felipe Arias Flechas
 * @author Jose Alberto Riascos Ruiz
 * @version 1.0
 * @since JDK 8
 */
public class GaussJordan extends JFrame {

    Algebra padre;
    JButton volver   = new JButton("Volver");
    JButton limpiar  = new JButton("Limpiar");
    JButton generar  = new JButton("Generar matriz");
    JButton resolver = new JButton("Resolver");

    JTextField cantEcu = new JTextField();
    JTextArea  res     = new JTextArea();

    // Celdas de la matriz ampliada [ecuacion][incognita + termino_independiente]
    List<List<JTextField>> celdas = new ArrayList<>();

    // Panel contenedor de la matriz (para poder repintarla)
    JPanel panelMatriz = new JPanel(null);

    int numEcu = 0; // última generación

    /**
     * Constructor. Inicializa y muestra la ventana de Gauss-Jordan.
     *
     * @param padre ventana del menú de Álgebra Lineal
     */
    public GaussJordan(Algebra padre) {
        super("GaussJordan");
        this.padre = padre;
        setSize(1024, 650);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(30, 10, 50));
        setResizable(false);
        setLayout(null);
        crearGUI();
        setVisible(true);
    }

    /**
     * Construye y agrega los componentes visuales de la ventana.
     */
    public void crearGUI() {

        JLabel titulo = new JLabel("ÁLGEBRA LINEAL - GAUSS JORDAN");
        titulo.setBounds(0, 0, 1024, 60);
        titulo.setOpaque(true);
        titulo.setBackground(new Color(142, 68, 173));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(JLabel.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 35));
        add(titulo);

        JLabel datos = new JLabel("Número de ecuaciones (máx. 5):");
        datos.setBounds(40, 85, 310, 30);
        datos.setFont(new Font("Arial", Font.ITALIC, 18));
        datos.setForeground(Color.WHITE);
        add(datos);

        cantEcu.setBounds(360, 88, 60, 25);
        add(cantEcu);

        ProyectoIntApp.estilizarBoton(generar, new Color(142, 68, 173));
        generar.setBounds(440, 85, 170, 30);
        generar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        generar.addActionListener((e) -> evento_generar());
        add(generar);

        // Panel de la matriz
        panelMatriz.setBounds(30, 125, 960, 220);
        panelMatriz.setBackground(new Color(30, 10, 50));
        add(panelMatriz);

        JLabel lblRes = new JLabel("Resultado / Pasos:");
        lblRes.setBounds(30, 350, 300, 25);
        lblRes.setFont(new Font("Arial", Font.ITALIC, 18));
        lblRes.setForeground(new Color(255, 220, 80));
        add(lblRes);

        res.setBounds(30, 378, 940, 160);
        res.setEditable(false);
        res.setFont(new Font("Monospaced", Font.PLAIN, 13));
        res.setBackground(new Color(20, 5, 35));
        res.setForeground(new Color(220, 180, 255));
        res.setLineWrap(false);
        JScrollPane scroll = new JScrollPane(res);
        scroll.setBounds(30, 378, 940, 160);
        add(scroll);

        ProyectoIntApp.estilizarBoton(resolver, new Color(108, 52, 131));
        resolver.setBounds(30, 548, 150, 30);
        resolver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        resolver.addActionListener((e) -> evento_resolver());
        add(resolver);

        ProyectoIntApp.estilizarBoton(volver, new Color(44, 62, 80));
        volver.setBounds(830, 548, 150, 30);
        volver.setCursor(new Cursor(Cursor.HAND_CURSOR));
        volver.addActionListener((e) -> evento_volver());
        add(volver);

        ProyectoIntApp.estilizarBoton(limpiar, new Color(22, 160, 133));
        limpiar.setBounds(200, 548, 150, 30);
        limpiar.setCursor(new Cursor(Cursor.HAND_CURSOR));
        limpiar.addActionListener((e) -> evento_limpiar());
        add(limpiar);
    }

    /**
     * Lee el número de ecuaciones y genera la cuadrícula de la matriz aumentada.
     */
    public void evento_generar() {
        try {
            int n = Integer.parseInt(cantEcu.getText().trim());
            if (n < 2 || n > 5) {
                JOptionPane.showMessageDialog(this, "El número de ecuaciones debe estar entre 2 y 5.", "Valor inválido", JOptionPane.WARNING_MESSAGE);
                return;
            }
            numEcu = n;
            generarMatriz(n);
            res.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa un número entero válido.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Crea dinámicamente los campos de texto que forman la matriz aumentada.
     *
     * @param n número de ecuaciones (entre 2 y 5)
     */
    private void generarMatriz(int n) {
        panelMatriz.removeAll();
        celdas.clear();

        int cellW = 55, cellH = 28, gapX = 8, gapY = 10;
        int cols = n + 1; // incógnitas + término independiente

        // Encabezados de columnas
        String[] varNames = {"x", "y", "z", "w", "v"};
        for (int j = 0; j < n; j++) {
            JLabel lbl = new JLabel(varNames[j], JLabel.CENTER);
            lbl.setBounds(j * (cellW + gapX), 0, cellW, 20);
            lbl.setFont(new Font("Arial", Font.BOLD, 13));
            lbl.setForeground(new Color(200, 160, 255));
            panelMatriz.add(lbl);
        }
        JLabel lblRes = new JLabel("= b", JLabel.CENTER);
        lblRes.setBounds(n * (cellW + gapX) + 15, 0, cellW, 20);
        lblRes.setFont(new Font("Arial", Font.BOLD, 13));
        lblRes.setForeground(new Color(255, 220, 100));
        panelMatriz.add(lblRes);

        // Celdas
        for (int i = 0; i < n; i++) {
            List<JTextField> fila = new ArrayList<>();
            for (int j = 0; j < cols; j++) {
                JTextField tf = new JTextField("0");
                tf.setHorizontalAlignment(JTextField.CENTER);
                int x = j < n ? j * (cellW + gapX) : j * (cellW + gapX) + 15;
                int y = 25 + i * (cellH + gapY);
                tf.setBounds(x, y, cellW, cellH);
                panelMatriz.add(tf);
                fila.add(tf);
            }
            celdas.add(fila);
        }

        // Separador vertical antes del término independiente
        // (representado con un label '|' en la primera fila)
        JLabel sep = new JLabel("|");
        sep.setBounds(n * (cellW + gapX) + 4, 25, 12, (n * (cellH + gapY)));
        sep.setFont(new Font("Arial", Font.BOLD, 22));
        sep.setForeground(new Color(200, 160, 255));
        panelMatriz.add(sep);

        panelMatriz.revalidate();
        panelMatriz.repaint();
    }

    /**
     * Lee la matriz, aplica el método Gauss-Jordan y muestra la solución paso a paso.
     */
    public void evento_resolver() {
        if (celdas.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Primero genera la matriz.", "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            int n = numEcu;
            // Leer la matriz aumentada
            double[][] mat = new double[n][n + 1];
            for (int i = 0; i < n; i++)
                for (int j = 0; j <= n; j++) {
                    String txt = celdas.get(i).get(j).getText().trim();
                    if (txt.isEmpty()) txt = "0";
                    mat[i][j] = Double.parseDouble(txt);
                }

            StringBuilder sb = new StringBuilder();
            sb.append("═══ MÉTODO GAUSS-JORDAN ═══\n\n");
            sb.append("Matriz aumentada inicial:\n");
            sb.append(matrizStr(mat, n));

            // ── Gauss-Jordan ────────────────────────────────────────────
            for (int col = 0; col < n; col++) {
                // Buscar pivote (el mayor valor absoluto en la columna)
                int pivFila = col;
                for (int i = col + 1; i < n; i++)
                    if (Math.abs(mat[i][col]) > Math.abs(mat[pivFila][col]))
                        pivFila = i;

                // Intercambiar filas si es necesario
                if (pivFila != col) {
                    double[] tmp = mat[col]; mat[col] = mat[pivFila]; mat[pivFila] = tmp;
                    sb.append(String.format("\nF%d ↔ F%d\n", col+1, pivFila+1));
                    sb.append(matrizStr(mat, n));
                }

                double pivote = mat[col][col];
                if (Math.abs(pivote) < 1e-12) {
                    // Columna de ceros: el sistema puede ser incompatible o tiene infinitas soluciones
                    continue;
                }

                // Normalizar la fila del pivote
                for (int j = 0; j <= n; j++) mat[col][j] /= pivote;
                sb.append(String.format("\nF%d ÷ %.4f  (normalizar pivote)\n", col+1, pivote));
                sb.append(matrizStr(mat, n));

                // Eliminar en todas las demás filas (hacia arriba y hacia abajo)
                for (int i = 0; i < n; i++) {
                    if (i == col) continue;
                    double factor = mat[i][col];
                    if (Math.abs(factor) < 1e-12) continue;
                    for (int j = 0; j <= n; j++) mat[i][j] -= factor * mat[col][j];
                    sb.append(String.format("\nF%d = F%d - (%.4f) × F%d\n", i+1, i+1, factor, col+1));
                    sb.append(matrizStr(mat, n));
                }
            }

            // ── Verificar consistencia y extraer soluciones ─────────────
            sb.append("\n═══ SOLUCIÓN ═══\n");
            boolean sinSolucion = false;
            for (int i = 0; i < n; i++) {
                boolean todoCero = true;
                for (int j = 0; j < n; j++) if (Math.abs(mat[i][j]) > 1e-9) { todoCero = false; break; }
                if (todoCero && Math.abs(mat[i][n]) > 1e-9) { sinSolucion = true; break; }
            }

            if (sinSolucion) {
                sb.append("El sistema NO tiene solución (es inconsistente).");
            } else {
                String[] varNames = {"x", "y", "z", "w", "v"};
                for (int i = 0; i < n; i++) {
                    double val = mat[i][n];
                    sb.append(String.format("  %s = %.6f\n", varNames[i], val));
                }
                // Verificación
                sb.append("\n── Verificación ──\n");
                double[][] orig = new double[n][n + 1];
                for (int i = 0; i < n; i++)
                    for (int j = 0; j <= n; j++) {
                        String txt = celdas.get(i).get(j).getText().trim();
                        if (txt.isEmpty()) txt = "0";
                        orig[i][j] = Double.parseDouble(txt);
                    }
                for (int i = 0; i < n; i++) {
                    double suma = 0;
                    StringBuilder eq = new StringBuilder("  ");
                    for (int j = 0; j < n; j++) {
                        suma += orig[i][j] * mat[j][n];
                        eq.append(String.format("%.4f×%.4f", orig[i][j], mat[j][n]));
                        if (j < n - 1) eq.append(" + ");
                    }
                    eq.append(String.format(" = %.4f  (esperado %.4f)", suma, orig[i][n]));
                    sb.append(eq).append("\n");
                }
            }

            res.setText(sb.toString());
            res.setCaretPosition(0);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Todos los valores de la matriz deben ser números.\nEj: 2, -1.5, 0", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Restablece el campo de cantidad y todas las celdas a cero.
     */
    public void evento_limpiar() {
        cantEcu.setText("");
        celdas.forEach(fila -> fila.forEach(tf -> tf.setText("0")));
        res.setText("");
        cantEcu.requestFocus();
    }

    /**
     * Cierra esta ventana y vuelve al menú de Álgebra Lineal.
     */
    public void evento_volver() {
        setVisible(false);
        dispose();
        padre.setVisible(true);
    }

    /**
     * Convierte la matriz aumentada en cadena formateada.
     *
     * @param m matriz aumentada de tamaño n×(n+1)
     * @param n número de ecuaciones
     * @return  representación textual de la matriz
     */
    private String matrizStr(double[][] m, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) {
            sb.append("  [");
            for (int j = 0; j < n; j++) sb.append(String.format(" %8.4f", m[i][j]));
            sb.append("  |  ").append(String.format("%8.4f", m[i][n])).append(" ]\n");
        }
        return sb.toString();
    }
}
